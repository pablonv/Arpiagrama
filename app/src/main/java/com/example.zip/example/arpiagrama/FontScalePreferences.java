package com.example.arpiagrama;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

public final class FontScalePreferences {
    private static final String PREFS_NAME = "font_scale_prefs";
    private static final String KEY_FONT_SCALE = "font_scale";
    private static final float DEFAULT_SCALE = 1.0f;
    private static final float MIN_SCALE = 0.85f;
    private static final float MAX_SCALE = 1.3f;
    private static final float STEP = 0.1f;

    private FontScalePreferences() {
    }

    public static Context applyFontScale(Context context) {
        float scale = getFontScale(context);
        Configuration configuration = context.getResources().getConfiguration();
        if (Math.abs(configuration.fontScale - scale) < 0.001f) {
            return context;
        }
        Configuration adjustedConfig = new Configuration(configuration);
        adjustedConfig.fontScale = scale;
        return context.createConfigurationContext(adjustedConfig);
    }

    public static float getFontScale(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return preferences.getFloat(KEY_FONT_SCALE, DEFAULT_SCALE);
    }

    public static float getMinScale() {
        return MIN_SCALE;
    }

    public static float getMaxScale() {
        return MAX_SCALE;
    }

    public static boolean increaseFontScale(Context context) {
        return updateFontScale(context, STEP);
    }

    public static boolean decreaseFontScale(Context context) {
        return updateFontScale(context, -STEP);
    }

    private static boolean updateFontScale(Context context, float delta) {
        float current = getFontScale(context);
        float updated = clamp(current + delta);
        if (Math.abs(updated - current) < 0.001f) {
            return false;
        }
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        preferences.edit().putFloat(KEY_FONT_SCALE, updated).apply();
        return true;
    }

    private static float clamp(float value) {
        return Math.max(MIN_SCALE, Math.min(MAX_SCALE, value));
    }
}
