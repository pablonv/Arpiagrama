package com.example.arpiagrama.ml;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.RectF;
import android.util.Log;

import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HandDetectorHelper {
    private static final String TAG = "HandDetectorHelper";
    private static final String MODEL_ASSET = "hand_landmarker.task";
    private static final int DEFAULT_NUM_HANDS = 2;

    private final Context appContext;
    private HandLandmarker handLandmarker;

    public HandDetectorHelper(Context context) {
        this.appContext = context.getApplicationContext();
        configurarLandmarker();
    }

    private void configurarLandmarker() {
        try {
            BaseOptions baseOptions = BaseOptions.builder()
                    .setModelAssetPath(MODEL_ASSET)
                    .build();

            HandLandmarker.HandLandmarkerOptions options =
                    HandLandmarker.HandLandmarkerOptions.builder()
                            .setBaseOptions(baseOptions)
                            .setMinHandDetectionConfidence(0.5f)
                            .setMinTrackingConfidence(0.5f)
                            .setMinHandPresenceConfidence(0.5f)
                            .setNumHands(DEFAULT_NUM_HANDS)
                            .setRunningMode(RunningMode.IMAGE)
                            .build();

            handLandmarker = HandLandmarker.createFromOptions(appContext, options);
        } catch (Exception e) {
            Log.w(TAG, "Não foi possível inicializar o filtro de mãos. A detecção continuará sem o filtro.", e);
            handLandmarker = null;
        }
    }

    public List<RectF> detectarMaos(Bitmap bitmap) {
        if (handLandmarker == null || bitmap == null) {
            return Collections.emptyList();
        }
        try {
            MPImage image = new BitmapImageBuilder(bitmap).build();
            HandLandmarkerResult result = handLandmarker.detect(image);
            List<RectF> boxes = new ArrayList<>();
            if (result == null) {
                return boxes;
            }

            List<List<NormalizedLandmark>> hands = result.landmarks();
            if (hands == null) {
                return boxes;
            }

            int width = bitmap.getWidth();
            int height = bitmap.getHeight();

            for (List<NormalizedLandmark> hand : hands) {
                if (hand == null || hand.isEmpty()) continue;
                float minX = 1f, minY = 1f, maxX = 0f, maxY = 0f;
                for (NormalizedLandmark lm : hand) {
                    if (lm == null) continue;
                    minX = Math.min(minX, lm.x());
                    minY = Math.min(minY, lm.y());
                    maxX = Math.max(maxX, lm.x());
                    maxY = Math.max(maxY, lm.y());
                }
                if (maxX < minX || maxY < minY) continue;
                RectF rect = new RectF(
                        clamp(minX * width, 0f, width),
                        clamp(minY * height, 0f, height),
                        clamp(maxX * width, 0f, width),
                        clamp(maxY * height, 0f, height)
                );
                boxes.add(rect);
            }
            return boxes;
        } catch (Exception e) {
            Log.w(TAG, "Falha ao processar filtro de mãos. Ignorando quadro.", e);
            return Collections.emptyList();
        }
    }

    private float clamp(float value, float min, float max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }

    public void close() {
        if (handLandmarker != null) {
            try {
                handLandmarker.close();
            } catch (Exception e) {
                Log.w(TAG, "Erro ao liberar HandLandmarker", e);
            }
            handLandmarker = null;
        }
    }
}
