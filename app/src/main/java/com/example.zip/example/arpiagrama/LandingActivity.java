package com.example.arpiagrama;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;

public class LandingActivity extends BaseActivity {

    private static final float FONT_SCALE_STEP = 0.1f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing);

        MaterialButton buttonUse = findViewById(R.id.button_use_arpiagrama);
        MaterialButton buttonVolunteer = findViewById(R.id.button_be_volunteer);
        MaterialButton buttonFontDecrease = findViewById(R.id.button_font_decrease);
        MaterialButton buttonFontIncrease = findViewById(R.id.button_font_increase);
        MaterialSwitch toggleDarkTheme = findViewById(R.id.button_toggle_dark_theme);

        buttonUse.setOnClickListener(v -> navigateToTerms(TermsActivity.MODE_USER));
        buttonVolunteer.setOnClickListener(v -> navigateToTerms(TermsActivity.MODE_VOLUNTEER));

        toggleDarkTheme.setChecked(ThemePreferences.isDarkThemeEnabled(this));
        toggleDarkTheme.setOnCheckedChangeListener(
                (buttonView, isChecked) -> ThemePreferences.setDarkThemeEnabled(this, isChecked)
        );

        buttonFontDecrease.setOnClickListener(v -> adjustFontScale(-FONT_SCALE_STEP));
        buttonFontIncrease.setOnClickListener(v -> adjustFontScale(FONT_SCALE_STEP));
        updateFontButtons(buttonFontDecrease, buttonFontIncrease);
    }

    private void navigateToTerms(int mode) {
        Intent intent = new Intent(this, TermsActivity.class);
        intent.putExtra(TermsActivity.EXTRA_MODE, mode);
        startActivity(intent);
    }

    private void adjustFontScale(float delta) {
        float currentScale = ThemePreferences.getFontScale(this);
        float updatedScale = ThemePreferences.clampFontScale(currentScale + delta);
        if (updatedScale != currentScale) {
            ThemePreferences.setFontScale(this, updatedScale);
            recreate();
        }
    }

    private void updateFontButtons(MaterialButton decreaseButton, MaterialButton increaseButton) {
        float currentScale = ThemePreferences.getFontScale(this);
        decreaseButton.setEnabled(currentScale > ThemePreferences.getMinFontScale());
        increaseButton.setEnabled(currentScale < ThemePreferences.getMaxFontScale());
    }
}
