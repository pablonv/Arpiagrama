package com.example.arpiagrama.context;

import android.app.Activity;
import androidx.appcompat.app.AlertDialog;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.arpiagrama.BuildConfig;
import com.example.arpiagrama.R;
import com.example.arpiagrama.speech.SpeechController;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class ContextDescriptionManager {
    private static final String TAG = "ContextDescriptionManager";
    private static final MediaType JSON_MEDIA_TYPE = MediaType.get("application/json; charset=utf-8");
    private static final String OPENAI_MODEL = "gpt-5.2";

    private final Activity activity;
    private final SpeechController speechController;
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    private final OkHttpClient httpClient = new OkHttpClient();

    private AlertDialog progressDialog;
    private boolean requestInProgress;

    public ContextDescriptionManager(@NonNull Activity activity, @NonNull SpeechController speechController) {
        this.activity = activity;
        this.speechController = speechController;
    }

    public boolean isRequestInProgress() {
        return requestInProgress;
    }

    public void requestDescription(@NonNull String base64Image, @NonNull String piecesSummary) {
        if (requestInProgress) {
            Toast.makeText(activity, R.string.context_description_in_progress, Toast.LENGTH_SHORT).show();
            return;
        }

        String apiKey = BuildConfig.OPENAI_API_KEY;
        if (apiKey == null) {
            apiKey = "";
        }
        apiKey = apiKey.trim();
        if (apiKey.isEmpty()) {
            showError(activity.getString(R.string.context_description_no_api_key));
            return;
        }

        if (base64Image.isEmpty()) {
            showError(activity.getString(R.string.context_description_no_frame));
            return;
        }

        final String prompt = buildPrompt(piecesSummary);
        final String finalApiKey = apiKey;

        requestInProgress = true;
        showProgress();

        executorService.execute(() -> {
            try {
                String description = requestFromOpenAi(base64Image, prompt, finalApiKey);
                activity.runOnUiThread(() -> {
                    requestInProgress = false;
                    hideProgress();
                    if (description != null && !description.isEmpty()) {
                        showDescription(description.trim());
                    } else {
                        showError(activity.getString(R.string.context_description_empty_response));
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Error requesting context description", e);
                activity.runOnUiThread(() -> {
                    requestInProgress = false;
                    hideProgress();
                    showError(activity.getString(R.string.context_description_error));
                });
            }
        });
    }

    public void shutdown() {
        hideProgress();
        requestInProgress = false;
        executorService.shutdownNow();
        httpClient.dispatcher().cancelAll();
        httpClient.dispatcher().executorService().shutdown();
        httpClient.connectionPool().evictAll();
    }

    private void showProgress() {
        if (activity.isFinishing() || activity.isDestroyed()) {
            return;
        }
        if (progressDialog == null) {
            ProgressBar progressBar = new ProgressBar(activity);
            progressBar.setIndeterminate(true);
            progressDialog = new AlertDialog.Builder(activity)
                    .setTitle(R.string.context_description_title)
                    .setMessage(R.string.context_description_requesting)
                    .setView(progressBar)
                    .setCancelable(false)
                    .create();
        } else {
            progressDialog.setMessage(activity.getString(R.string.context_description_requesting));
        }
        progressDialog.show();
    }

    private void hideProgress() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    private void showDescription(@NonNull String description) {
        if (!activity.isFinishing() && !activity.isDestroyed()) {
            new AlertDialog.Builder(activity)
                    .setTitle(R.string.context_description_title)
                    .setMessage(description)
                    .setPositiveButton(android.R.string.ok, null)
                    .show();
        }
        speechController.speakQueued(description);
    }

    private void showError(@NonNull String message) {
        Toast.makeText(activity, message, Toast.LENGTH_LONG).show();
        speechController.speakQueued(message);
    }

    @NonNull
    private String buildPrompt(@NonNull String piecesSummary) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("Contexto: diagrama de caso de uso.\n");
        prompt.append("Analise a imagem enviada com detalhe pegando todas as nomeações atribuidas e gere uma descrição curta, acessível para deficientes visuais e em português sem usar '*'. Se tiver um dedo na imagem proximo a algum elemento: descreva apenas o elemento e suas conexões (ou seja, verifique se existe uma seta de relacionamento conectado-se a outro elemento) e, se não houver nenhum relacionamento proximo ao elemento que o dedo está apontado, descreve somente o elemento apontado. E caso contrario (não haja dedo para nenhum elemento) faça uma descrição de toda imagem de forma curta e acessivel para pessoas com DV destacando atores, casos de uso e relações com suas definições em uma unica frase.\n");
        if (piecesSummary.isEmpty()) {
            prompt.append("Não há peças nomeadas pelo usuário.");
        } else {
            prompt.append("Peças nomeadas pelo usuário:\n");
            prompt.append(piecesSummary);
        }
        return prompt.toString();
    }

    private String requestFromOpenAi(@NonNull String base64Image, @NonNull String prompt, @NonNull String apiKey) throws IOException, JSONException {
        JSONObject imageUrl = new JSONObject();
        imageUrl.put("url", "data:image/jpeg;base64," + base64Image);

        JSONObject imageContent = new JSONObject();
        imageContent.put("type", "image_url");
        imageContent.put("image_url", imageUrl);

        JSONObject textContent = new JSONObject();
        textContent.put("type", "text");
        textContent.put("text", prompt);

        JSONArray contentArray = new JSONArray();
        contentArray.put(textContent);
        contentArray.put(imageContent);

        JSONObject message = new JSONObject();
        message.put("role", "user");
        message.put("content", contentArray);

        JSONArray messages = new JSONArray();
        messages.put(message);

        JSONObject requestBodyJson = new JSONObject();
        requestBodyJson.put("model", OPENAI_MODEL);
        requestBodyJson.put("messages", messages);

        RequestBody body = RequestBody.create(requestBodyJson.toString(), JSON_MEDIA_TYPE);

        Request request = new Request.Builder()
                .url("https://api.openai.com/v1/chat/completions")
                .post(body)
                .addHeader("Authorization", "Bearer " + apiKey)
                .addHeader("Content-Type", "application/json")
                .build();

        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            }
            ResponseBody responseBody = response.body();
            if (responseBody == null) {
                throw new IOException("Empty response body");
            }
            String responseString = responseBody.string();
            return extractDescription(responseString);
        }
    }

    private String extractDescription(@NonNull String responseString) throws JSONException {
        JSONObject json = new JSONObject(responseString);
        JSONArray choices = json.optJSONArray("choices");
        if (choices == null || choices.length() == 0) {
            return null;
        }
        JSONObject firstChoice = choices.getJSONObject(0);
        JSONObject message = firstChoice.optJSONObject("message");
        if (message == null) {
            return null;
        }
        return message.optString("content", null);
    }
}
