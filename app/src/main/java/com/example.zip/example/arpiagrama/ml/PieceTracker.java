package com.example.arpiagrama.ml;

import android.graphics.RectF;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Multi-objeto simples baseado em tracking-by-detection.
 *
 * - Associação por classe + distância de centro (com fallback por IoU).
 * - Estados com janela de oclusão: PENDING -> CONFIRMADA -> POSSIVEL_OCLUSAO -> REMOVIDA.
 * - Remoção apenas se ausência persistir por tempo em ms (não em frames) e com
 *   heurística de movimento para evitar falsos positivos quando o usuário cobre a peça.
 */
public class PieceTracker {

    private static final long REAPPEAR_GRACE_MS = 5000L;

    public enum TrackState { PENDING, CONFIRMADA, POSSIVEL_OCLUSAO, REMOVIDA }

    public static class TrackedPiece {
        private final long id;
        private final String className;
        private float averageConfidence;
        private RectF estimatedBox;
        private float velocityX;
        private float velocityY;
        private long firstSeenMs;
        private long confirmedAtMs;
        private long lastSeenMs;
        private Long missingSinceMs;
        private TrackState state;
        private boolean matchedThisFrame;
        private float lastMovementPx;
        private long lastMovementMs;

        TrackedPiece(long id, String className, Recognition detection, long nowMs) {
            this.id = id;
            this.className = normalizeLabel(className);
            this.estimatedBox = detection.getLocation() != null ? new RectF(detection.getLocation()) : null;
            this.averageConfidence = detection.getConfidence();
            this.firstSeenMs = nowMs;
            this.lastSeenMs = nowMs;
            this.state = TrackState.PENDING;
            this.matchedThisFrame = true;
        }

        TrackedPiece(TrackedPiece other) {
            this.id = other.id;
            this.className = other.className;
            this.averageConfidence = other.averageConfidence;
            this.estimatedBox = other.estimatedBox != null ? new RectF(other.estimatedBox) : null;
            this.velocityX = other.velocityX;
            this.velocityY = other.velocityY;
            this.firstSeenMs = other.firstSeenMs;
            this.confirmedAtMs = other.confirmedAtMs;
            this.lastSeenMs = other.lastSeenMs;
            this.missingSinceMs = other.missingSinceMs;
            this.state = other.state;
            this.matchedThisFrame = other.matchedThisFrame;
            this.lastMovementPx = other.lastMovementPx;
            this.lastMovementMs = other.lastMovementMs;
        }

        void updateWithDetection(Recognition detection, long nowMs, long addThresholdMs) {
            if (detection.getLocation() != null) {
                RectF newBox = new RectF(detection.getLocation());
                if (estimatedBox != null) {
                    float dtSec = Math.max(1e-3f, (nowMs - lastSeenMs) / 1000f);
                    float dx = centerX(newBox) - centerX(estimatedBox);
                    float dy = centerY(newBox) - centerY(estimatedBox);
                    velocityX = dx / dtSec;
                    velocityY = dy / dtSec;
                    float disp = (float) Math.hypot(dx, dy);
                    lastMovementPx = disp;
                    lastMovementMs = nowMs;
                }
                estimatedBox = newBox;
            }
            float conf = detection.getConfidence();
            averageConfidence = (averageConfidence == 0f) ? conf : (0.6f * averageConfidence + 0.4f * conf);
            lastSeenMs = nowMs;
            matchedThisFrame = true;
            missingSinceMs = null;

            if (state == TrackState.PENDING && (nowMs - firstSeenMs) >= addThresholdMs) {
                state = TrackState.CONFIRMADA;
                confirmedAtMs = nowMs;
            } else if (state == TrackState.POSSIVEL_OCLUSAO) {
                state = TrackState.CONFIRMADA;
                if (confirmedAtMs == 0L) {
                    confirmedAtMs = nowMs;
                }
            }
        }

        void markMissing(long nowMs,
                         long removeThresholdMs,
                         long occlusionExtensionMs,
                         float movementEvidencePx,
                         int frameWidth,
                         int frameHeight,
                         boolean blockedByHand,
                         long handClearMs) {
            if (state == TrackState.REMOVIDA) return;

            if (missingSinceMs == null) missingSinceMs = nowMs;
            matchedThisFrame = false;
            if (state == TrackState.CONFIRMADA || state == TrackState.PENDING) {
                state = TrackState.POSSIVEL_OCLUSAO;
            }

            if (blockedByHand) {
                missingSinceMs = nowMs;
                return;
            }

            // Prever posição usando velocidade para manter associação em oclusões.
            if (estimatedBox != null) {
                float dtSec = Math.max(0f, (nowMs - lastSeenMs) / 1000f);
                RectF predicted = new RectF(estimatedBox);
                predicted.offset(velocityX * dtSec, velocityY * dtSec);
                clampToFrame(predicted, frameWidth, frameHeight);
                estimatedBox = predicted;
            }

            long missingDuration = nowMs - missingSinceMs;
            long removalDeadline = removeThresholdMs;
            boolean hasMovementEvidence = hasRecentMovement(nowMs, movementEvidencePx);
            if (!hasMovementEvidence) {
                removalDeadline += occlusionExtensionMs;
            }
            if (handClearMs > 0L) {
                removalDeadline += handClearMs;
            }

            if (missingDuration >= removalDeadline) {
                state = TrackState.REMOVIDA;
            }
        }

        private boolean hasRecentMovement(long nowMs, float movementEvidencePx) {
            if (lastMovementMs == 0L) return false;
            boolean displaced = lastMovementPx >= movementEvidencePx;
            boolean recent = (nowMs - lastMovementMs) <= REAPPEAR_GRACE_MS;
            return displaced || recent;
        }

        public long getId() { return id; }
        public String getClassName() { return className; }
        public float getAverageConfidence() { return averageConfidence; }
        public RectF getEstimatedBox() { return estimatedBox != null ? new RectF(estimatedBox) : null; }
        public long getLastSeenMs() { return lastSeenMs; }
        public Long getMissingSinceMs() { return missingSinceMs; }
        public TrackState getState() { return state; }
        public boolean wasUpdatedThisFrame() { return matchedThisFrame; }
        public long getConfirmedAtMs() { return confirmedAtMs; }

        public Recognition asRecognition() {
            if (estimatedBox == null) return null;
            return new Recognition(className, averageConfidence, String.valueOf(id), new RectF(estimatedBox), className);
        }

        static float centerX(RectF rect) { return (rect.left + rect.right) * 0.5f; }
        static float centerY(RectF rect) { return (rect.top + rect.bottom) * 0.5f; }
        static void clampToFrame(RectF rect, int frameWidth, int frameHeight) {
            if (frameWidth <= 0 || frameHeight <= 0 || rect == null) return;
            rect.left = Math.max(0f, Math.min(rect.left, frameWidth));
            rect.top = Math.max(0f, Math.min(rect.top, frameHeight));
            rect.right = Math.max(0f, Math.min(rect.right, frameWidth));
            rect.bottom = Math.max(0f, Math.min(rect.bottom, frameHeight));
        }
    }

    private final List<TrackedPiece> tracks = new ArrayList<>();
    private long nextId = 1L;
    private final long addThresholdMs;
    private final long removeThresholdMs;
    private final long occlusionExtensionMs;
    private final float movementEvidencePx;
    private final float baseMatchDistancePx;
    private float maxMatchDistancePx;
    private int frameWidth = 0;
    private int frameHeight = 0;

    public PieceTracker(long addThresholdMs,
                        long removeThresholdMs,
                        long occlusionExtensionMs,
                        float movementEvidencePx,
                        float matchDistancePx) {
        this.addThresholdMs = addThresholdMs;
        this.removeThresholdMs = removeThresholdMs;
        this.occlusionExtensionMs = occlusionExtensionMs;
        this.movementEvidencePx = movementEvidencePx;
        this.baseMatchDistancePx = matchDistancePx;
        this.maxMatchDistancePx = matchDistancePx;
    }

    public void setFrameSize(int width, int height) {
        this.frameWidth = width;
        this.frameHeight = height;
        float diag = (float) Math.hypot(Math.max(1, width), Math.max(1, height));
        this.maxMatchDistancePx = Math.max(baseMatchDistancePx, diag * 0.06f);
    }

    public List<TrackedPiece> update(List<Recognition> detections, long nowMs, OcclusionBlocker occlusionBlocker, long handClearMs) {
        List<Recognition> safeDetections = detections != null ? detections : Collections.emptyList();
        boolean[] detectionMatched = new boolean[safeDetections.size()];
        Set<TrackedPiece> updatedTracks = new HashSet<>();

        // Reset flags for this frame
        for (TrackedPiece track : tracks) {
            track.matchedThisFrame = false;
        }

        // Associação greedy por classe + distância de centro (predição se estiver ausente).
        List<TrackedPiece> availableTracks = new ArrayList<>();
        for (TrackedPiece track : tracks) {
            if (track.state != TrackState.REMOVIDA) {
                availableTracks.add(track);
            }
        }

        for (int i = 0; i < safeDetections.size(); i++) {
            Recognition detection = safeDetections.get(i);
            RectF detBox = detection.getLocation();
            if (detBox == null) continue;

            TrackedPiece bestTrack = null;
            float bestCost = Float.MAX_VALUE;

            for (TrackedPiece candidate : availableTracks) {
                if (!classesCompat(candidate.className, detection.getTitle())) continue;
                float cost = distanceToTrack(candidate, detBox, nowMs);
                if (cost < bestCost && cost <= maxMatchDistancePx) {
                    bestCost = cost;
                    bestTrack = candidate;
                }
            }

            if (bestTrack != null) {
                bestTrack.updateWithDetection(detection, nowMs, addThresholdMs);
                updatedTracks.add(bestTrack);
                detectionMatched[i] = true;
                availableTracks.remove(bestTrack);
            }
        }

        // Criar trilhas novas para detecções não associadas
        for (int i = 0; i < safeDetections.size(); i++) {
            if (detectionMatched[i]) continue;
            Recognition detection = safeDetections.get(i);
            if (detection.getLocation() == null) continue;
            TrackedPiece newTrack = new TrackedPiece(nextId++, detection.getTitle(), detection, nowMs);
            tracks.add(newTrack);
            updatedTracks.add(newTrack);
        }

        // Marcar ausências e aplicar janela temporal de remoção
        for (TrackedPiece track : tracks) {
            if (!updatedTracks.contains(track)) {
                boolean blocked = occlusionBlocker != null && occlusionBlocker.isBlocked(track, nowMs);
                track.markMissing(nowMs, removeThresholdMs, occlusionExtensionMs, movementEvidencePx, frameWidth, frameHeight, blocked, handClearMs);
            } else if (track.getMissingSinceMs() != null && (nowMs - track.getMissingSinceMs()) <= REAPPEAR_GRACE_MS) {
                track.state = TrackState.CONFIRMADA;
            }
        }

        // Limpeza de trilhas removidas antigas
        tracks.removeIf(track -> track.state == TrackState.REMOVIDA && (nowMs - track.lastSeenMs) > (removeThresholdMs * 2));

        return snapshot();
    }

    public TrackedPiece findById(Long id) {
        if (id == null) return null;
        for (TrackedPiece track : tracks) {
            if (track.id == id) return new TrackedPiece(track);
        }
        return null;
    }

    private List<TrackedPiece> snapshot() {
        List<TrackedPiece> copy = new ArrayList<>();
        for (TrackedPiece track : tracks) {
            copy.add(new TrackedPiece(track));
        }
        return copy;
    }

    public interface OcclusionBlocker {
        boolean isBlocked(TrackedPiece piece, long nowMs);
    }

    private float distanceToTrack(TrackedPiece track, RectF detBox, long nowMs) {
        RectF trackBox = track.estimatedBox != null ? new RectF(track.estimatedBox) : null;
        if (trackBox == null) return Float.MAX_VALUE;

        if (!track.matchedThisFrame && track.missingSinceMs != null) {
            float dtSec = Math.max(0f, (nowMs - track.lastSeenMs) / 1000f);
            trackBox.offset(track.velocityX * dtSec, track.velocityY * dtSec);
            TrackedPiece.clampToFrame(trackBox, frameWidth, frameHeight);
        }

        float centerDist = (float) Math.hypot(
                TrackedPiece.centerX(detBox) - TrackedPiece.centerX(trackBox),
                TrackedPiece.centerY(detBox) - TrackedPiece.centerY(trackBox)
        );

        float iou = iou(trackBox, detBox);
        float iouPenalty = (1f - iou) * Math.max(frameWidth, frameHeight) * 0.01f;
        return centerDist + iouPenalty;
    }

    private static boolean classesCompat(String a, String b) {
        String na = normalizeLabel(a);
        String nb = normalizeLabel(b);
        if (na.isEmpty() || nb.isEmpty()) return true;
        return na.equalsIgnoreCase(nb);
    }

    private static String normalizeLabel(String raw) {
        if (raw == null) return "";
        return raw.trim().toLowerCase(Locale.ROOT);
    }

    private static float iou(RectF a, RectF b) {
        if (a == null || b == null) return 0f;
        float interW = Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left));
        float interH = Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
        float inter = interW * interH;
        float areaA = Math.max(0, a.width()) * Math.max(0, a.height());
        float areaB = Math.max(0, b.width()) * Math.max(0, b.height());
        float uni = areaA + areaB - inter;
        return uni <= 0 ? 0f : inter / uni;
    }
}
