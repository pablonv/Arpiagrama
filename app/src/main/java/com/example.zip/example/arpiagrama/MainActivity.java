package com.example.arpiagrama;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Base64;
import android.util.Log;
import android.util.Size;
import android.util.TypedValue;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.pdf.PdfDocument;
import android.view.Surface;
import android.view.KeyEvent;

import androidx.annotation.NonNull;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import com.example.arpiagrama.Drawing.BorderedText;
import com.example.arpiagrama.Drawing.MultiBoxTracker;
import com.example.arpiagrama.Drawing.OverlayView;
import com.example.arpiagrama.context.ContextDescriptionManager;
import com.example.arpiagrama.livefeed.CameraConnectionFragment;
import com.example.arpiagrama.livefeed.ImageUtils;
import com.example.arpiagrama.ml.HandDetectorHelper;
import com.example.arpiagrama.ml.ObjectDetectorHelper;
import com.example.arpiagrama.ml.Recognition;
import com.example.arpiagrama.ml.YoloV8TfliteDetector;
import com.example.arpiagrama.speech.SpeechController;
import com.google.mediapipe.tasks.components.containers.Category;
import com.google.mediapipe.tasks.components.containers.Detection;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetectionResult;

import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.graphics.RectF;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * MainActivity com:
 * - seleção automática de câmera 0.5x (ultra-wide) se existir;
 * - preview FIT (feito no CameraConnectionFragment);
 * - todo o seu fluxo anterior de detecção/nomeação permanece igual.
 *
 * OBS: este arquivo é baseado na sua versão mais recente com TTS, diálogo, etc.
 *      Ajuste getters de Recognition se necessário (getTitle / getLabel...).
 */
public class MainActivity extends BaseActivity
        implements ImageReader.OnImageAvailableListener, ObjectDetectorHelper.DetectorListener {

    private Handler handler;
    private Matrix frameToCropTransform;
    private Matrix cropToFrameTransform;
    private int sensorOrientation;
    private static final int TF_OD_API_INPUT_SIZE = 320;
    private static final boolean MAINTAIN_ASPECT = false;
    private static final float TEXT_SIZE_DIP = 10;
    private static final int PERMISSION_CODE = 321;
    private static final int AUDIO_PERMISSION_CODE = 322;
    private static final int CONTEXT_IMAGE_MAX_DIMENSION = 1024;
    private static final long CONFIRMATION_NO_RESPONSE_DELAY_MS = 10000L;
    private static final long NAME_LISTEN_WINDOW_MS = 5000L;

    private static final Size DEFAULT_PREVIEW_SIZE = new Size(1920, 1080);

    private final CameraSelectorStrategy cameraSelector = new BackCameraFirstSelector();

    private OverlayView trackingOverlay;
    private BorderedText borderedText;
    private MultiBoxTracker tracker;

    private YoloV8TfliteDetector yoloDetector;
    //private ObjectDetectorHelper objectDetectorHelper;
    private HandDetectorHelper handDetectorHelper;
    private static final float MIN_CONFIDENCE = 0.80f;

    private SpeechController speechController;
    private ContextDescriptionManager contextDescriptionManager;
    private SpeechRecognizer speechRecognizer;
    private Intent speechRecognizerIntent;
    private EditText pendingVoiceInputTarget;
    private boolean listeningForInteractiveDescription = false;
    private boolean pendingInteractiveDescriptionRequest = false;
    private boolean awaitingNameConfirmation = false;
    private boolean listeningForNameConfirmation = false;
    private boolean namePromptSpoken = false;
    private boolean listeningForExportFormat = false;
    private boolean pendingExportFormatRequest = false;
    private Runnable confirmationNoResponseRunnable = null;
    private Runnable nameListeningTimeoutRunnable = null;
    private boolean ignoreNextNameError = false;
    private String lastSpokenName = null;
    private boolean nomeDefinidoPorVoz = false;
    private boolean isListeningName = false;
    private static final String INTERACTIVE_DESCRIPTION_COMMAND = "descricao interativa";

    private static final long STABILITY_MS = 3000L;
    private static final float CENTER_TOL_FRAC = 0.12f;

    private static final long FREEZE_RECHECK_INTERVAL_MS = 4000L;
    private static final float PRESENCE_IOU_THR = 0.40f;
    private static final float HAND_OVERLAP_IOU_THR = 0.20f;
    private static final float PRESENCE_CENTER_TOL_FRAC = 0.25f;
    private static final long NAME_REMINDER_DELAY_MS = 10_000L;
    private static final long HAND_PERSISTENCE_MS = 15000L;
    private static final long HAND_DOWNLOAD_COOLDOWN_MS = 500L;
    private static final long MULTI_PIECE_WARN_THRESHOLD_MS = 3000L;
    private static final long MULTI_PIECE_REPEAT_INTERVAL_MS = 10000L;
    private static final String HAND_PERSISTENCE_MESSAGE = "Para que evitar não detecção ou exclusão da peça, fique tateando por no máximo 1 minuto";
    private static final String DATASET_CONFIG_ASSET = "data.yaml";
    private static final float ROI_WIDTH_FRACTION = 0.90f; // 90% da largura da câmera
    private static final float ROI_HEIGHT_FRACTION = 0.80f; // 80% da altura da câmera

    private static final String TAG = "MainActivity";

    private void run() {
        if (interactionState == InteractionState.DEFININDO_PECA || dialogoNomeAberto()) {
            return;
        }
        if (!lastPieceActivityWasDefinition) {
            return;
        }
        long now = System.currentTimeMillis();
        long elapsed = now - lastPieceActivityMs;
        if (elapsed < NAME_REMINDER_DELAY_MS) {
            nameReminderHandler.postDelayed(nameReminderRunnable, NAME_REMINDER_DELAY_MS - elapsed);
            return;
        }
        falarEmFila("Você pode clicar em descrição contextual para ouvir a descrição do diagrama gerado por IA ou em Salvar para baixar em PNG/PDF ou compartilhar.");
    }

    //1 imagem ~ 0,004
    private enum SaveFormat {
        PNG,
        PDF
    }

    private enum InteractionState {
        AGUARDANDO_PECA,
        PECA_TRAVADA,
        DEFININDO_PECA
    }

    private InteractionState interactionState = InteractionState.AGUARDANDO_PECA;
    private RectF lastBox = null;
    private String lastStableLabel = null;
    private long stableSinceMs = 0L;
    private final Paint roiPaint = new Paint();
    private final Paint roiLegendTextPaint = new Paint();
    private final Paint roiLegendBackgroundPaint = new Paint();
    private final Paint roiActorLegendPaint = new Paint();
    private final Paint roiUseCaseLegendPaint = new Paint();
    private final Paint roiRelationLegendPaint = new Paint();

    private final List<RectF> frozenBoxes = new ArrayList<>();
    private final List<String> frozenLabels = new ArrayList<>();
    private final List<Long> frozenLastSeenMs = new ArrayList<>();
    private final List<String> frozenTypes = new ArrayList<>();
    private final List<RectF> exportFrozenBoxes = new ArrayList<>();
    private final List<String> exportFrozenLabels = new ArrayList<>();
    private final List<Long> exportFrozenLastSeenMs = new ArrayList<>();
    private final List<String> exportFrozenTypes = new ArrayList<>();

    private boolean nameDialogShown = false;
    private AlertDialog currentNameDialog = null;
    private int pendingNameIndex = -1;
    private String pendingClassSpoken = null;
    private static final float PENDING_PIECE_EXCLUSION_IOU = 0.35f;

    private AlertDialog removalDecisionDialog = null;
    private boolean listeningForRemovalDecision = false;
    private boolean pendingRemovalDecisionRequest = false;
    private String pendingRemovalName = null;
    private String pendingRemovalType = null;

    private String pendingRelocationName = null;
    private String pendingRelocationType = null;
    private RectF relocationLastBox = null;
    private long relocationStableSinceMs = 0L;

    private Runnable listeningWindowTimeoutRunnable = null;

    private long multiPieceDetectedSinceMs = 0L;
    private boolean multiPieceWarningSent = false;
    private long multiPieceLastWarningMs = 0L;

    private boolean isProcessingFrame = false;
    private final byte[][] yuvBytes = new byte[3][];
    private int[] rgbBytes = null;
    private int yRowStride;

    private ActivityResultLauncher<Intent> createDocumentLauncher;
    private Bitmap pendingCombinedBitmap = null;
    private Bitmap pendingExportChoiceBitmap = null;
    private SaveFormat pendingSaveFormat = null;
    private Runnable postInferenceCallback;
    private Runnable imageConverter;
    private Bitmap rgbFrameBitmap;
    private Bitmap roiMaskedBitmap;
    private Bitmap croppedBitmap;
    private int previewHeight = 0, previewWidth = 0;
    private final Object latestFrameLock = new Object();
    private Bitmap latestFrameForExport;
    private boolean detectionPaused = false;
    private boolean detectionPausedForExport = false;
    private boolean pendingShareReturn = false;
    private boolean exportStateCaptured = false;
    private RectF detectionRoi = null;
    private final List<RectF> detectedHandBoxes = new ArrayList<>();
    private long handsSeenSinceMs = 0L;
    private long lastHandsSeenMs = 0L;
    private boolean handWarningShown = false;
    private AlertDialog exportFormatDialog = null;

    private long lastPieceActivityMs = 0L;
    private boolean lastPieceActivityWasDefinition = false;

    private final Handler nameReminderHandler = new Handler(Looper.getMainLooper());
    private final Runnable nameReminderRunnable = this::run;

    private boolean welcomeMessageSpoken = false;
    private final Set<String> rotulosNd = new HashSet<>();

    private Handler freezeHandler;
    private final Runnable freezeWatcher = new Runnable() {
        @Override public void run() {
            if (detectionPausedForExport) {
                if (freezeHandler != null) {
                    freezeHandler.postDelayed(this, FREEZE_RECHECK_INTERVAL_MS);
                }
                return;
            }
            try {
                long now = System.currentTimeMillis();
                for (int i = frozenBoxes.size() - 1; i >= 0; i--) {
                    long last = frozenLastSeenMs.get(i);
                    if (now - last >= FREEZE_RECHECK_INTERVAL_MS) {
                        String removedName = frozenLabels.get(i);
                        String removedType = (i < frozenTypes.size()) ? frozenTypes.get(i) : null;
                        boolean namedPiece = removedName != null && !removedName.isEmpty();
                        if (interactionState == InteractionState.DEFININDO_PECA && namedPiece && i != pendingNameIndex) {
                            continue;
                        }
                        removerPecaCongelada(i);

                        interromperAudiosParaAcaoDePeca();
                        if (namedPiece) {
                            falarEmFila("Peça " + formatarTipoPeca(removedType) + " \"" + removedName + "\" removida do quadro.");
                        } else {
                            falarEmFila(mensagemPecaRemovida(removedType));
                        }
                    }
                }
            } finally {
                if (freezeHandler != null) {
                    freezeHandler.postDelayed(this, FREEZE_RECHECK_INTERVAL_MS);
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        handler = new Handler();

        createDocumentLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                this::onCreateDocumentResult
        );

        configurarBotao(R.id.button_context_description, this::solicitarDescricaoContextual);
        configurarBotao(R.id.button_download_image, this::solicitarDownloadQuadroAtual);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED){
                String[] permission = {Manifest.permission.CAMERA};
                requestPermissions(permission, PERMISSION_CODE);
            } else {
                configurarFragmento();
            }
        } else {
            configurarFragmento();
        }

        tracker = new MultiBoxTracker(this);
        carregarRotulosDataset();

        try {
            yoloDetector = new YoloV8TfliteDetector(
                    getApplicationContext(),
                    "best_float16.tflite",
                    "data.yaml",
                    0.25f, // CONF_THRES (igual seu Colab)
                    0.45f, // IOU_THRES
                    4      // threads (ajuste conforme device)
            );
        } catch (IOException e) {
            Log.e("MainActivity", "Erro carregando YOLO TFLite", e);
        }

        /*
        objectDetectorHelper = new ObjectDetectorHelper(
                0.5f,
                ObjectDetectorHelper.MAX_RESULTS_DEFAULT,
                ObjectDetectorHelper.DELEGATE_CPU,
                               "best_float16.tflite",
                RunningMode.IMAGE,
                getApplicationContext(),
                this
        );
*/
        handDetectorHelper = new HandDetectorHelper(getApplicationContext());

        speechController = new SpeechController(getApplicationContext());
        contextDescriptionManager = new ContextDescriptionManager(this, speechController);
        configurarReconhecimentoVoz();

        freezeHandler = new Handler();
        freezeHandler.postDelayed(freezeWatcher, FREEZE_RECHECK_INTERVAL_MS);
    }

    private void carregarRotulosDataset() {
        rotulosNd.clear();
        List<String> nomes = lerNomesDataYaml();
        for (String nome : nomes) {
            if ("nd".equals(normalizarRotulo(nome))) {
                rotulosNd.add(normalizarRotulo(nome));
            }
        }
        rotulosNd.add("nd");
    }

    private List<String> lerNomesDataYaml() {
        List<String> nomes = new ArrayList<>();
        try (InputStream inputStream = getAssets().open(DATASET_CONFIG_ASSET);
             InputStreamReader reader = new InputStreamReader(inputStream);
             BufferedReader bufferedReader = new BufferedReader(reader)) {
            boolean lendoNomes = false;
            String linha;
            while ((linha = bufferedReader.readLine()) != null) {
                String conteudo = linha.trim();
                if (!lendoNomes) {
                    if (conteudo.equals("names:")) {
                        lendoNomes = true;
                    }
                    continue;
                }
                if (conteudo.startsWith("-")) {
                    String nome = conteudo.substring(1).trim();
                    if (!nome.isEmpty()) {
                        nomes.add(nome);
                    }
                } else if (!conteudo.isEmpty()) {
                    break;
                }
            }
        } catch (IOException e) {
            Log.w(TAG, "Não foi possível ler data.yaml para carregar classes do dataset.", e);
        }
        return nomes;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pendingShareReturn) {
            pendingShareReturn = false;
            liberarBitmapPendente();
            retomarDeteccaoAposExportacao();
        }
    }

    @Override
    protected boolean onFunctionKeyPressed(int keyCode) {
        if (keyCode == KeyEvent.KEYCODE_F1) {
            solicitarDescricaoContextual();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_F2) {
            solicitarDownloadQuadroAtual();
            return true;
        }
        return super.onFunctionKeyPressed(keyCode);
    }



    private void configurarBotao(int buttonId, Runnable action) {
        Button botao = findViewById(buttonId);
        if (botao != null && action != null) {
            botao.setOnClickListener(v -> action.run());
        }
    }

    private void solicitarDescricaoContextual() {
        if (contextDescriptionManager == null) {
            return;
        }
        if (contextDescriptionManager.isRequestInProgress()) {
            Toast.makeText(this, R.string.context_description_in_progress, Toast.LENGTH_SHORT).show();
            return;
        }

        String base64Image = obterImagemAtualBase64();
        if (base64Image == null) {
            base64Image = "";
        }

        String piecesSummary = montarResumoPecas();
        contextDescriptionManager.requestDescription(base64Image, piecesSummary);
    }

    private String montarResumoPecas() {
        List<RectF> boxesSnapshot = new ArrayList<>();
        List<String> labelsSnapshot = new ArrayList<>();

        synchronized (frozenBoxes) {
            for (RectF box : frozenBoxes) {
                boxesSnapshot.add(new RectF(box));
            }
            labelsSnapshot.addAll(frozenLabels);
        }

        if (boxesSnapshot.isEmpty()) {
            return "";
        }

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < boxesSnapshot.size(); i++) {
            if (builder.length() > 0) {
                builder.append('\n');
            }
            String label = (i < labelsSnapshot.size()) ? labelsSnapshot.get(i) : null;
            String nome = label == null ? "" : label.trim();
            builder.append("- Peça ").append(i + 1).append(": ");
            if (!nome.isEmpty()) {
                builder.append(nome);
            } else {
                builder.append("sem nome");
            }
            String regiao = descreverRegiao(boxesSnapshot.get(i));
            if (regiao != null && !regiao.isEmpty()) {
                builder.append(" (").append(regiao).append(')');
            }
        }
        return builder.toString();
    }

    private String obterImagemAtualBase64() {
        Bitmap frameCopy;
        synchronized (latestFrameLock) {
            if (latestFrameForExport == null) {
                return null;
            }
            frameCopy = latestFrameForExport.copy(Bitmap.Config.ARGB_8888, false);
        }

        if (frameCopy == null) {
            return null;
        }

        Bitmap processed = reduzirBitmapSeNecessario(frameCopy);
        if (processed != frameCopy) {
            frameCopy.recycle();
        }

        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            boolean compressed = processed.compress(Bitmap.CompressFormat.JPEG, 85, outputStream);
            if (!compressed) {
                return null;
            }
            byte[] bytes = outputStream.toByteArray();
            return Base64.encodeToString(bytes, Base64.NO_WRAP);
        } catch (Exception e) {
            Log.e(TAG, "Erro ao converter imagem para Base64", e);
            return null;
        } finally {
            if (!processed.isRecycled()) {
                processed.recycle();
            }
        }
    }

    private Bitmap reduzirBitmapSeNecessario(@NonNull Bitmap bitmap) {
        int largura = bitmap.getWidth();
        int altura = bitmap.getHeight();
        int maior = Math.max(largura, altura);
        if (maior <= CONTEXT_IMAGE_MAX_DIMENSION) {
            return bitmap;
        }
        float escala = (float) CONTEXT_IMAGE_MAX_DIMENSION / maior;
        int novaLargura = Math.max(1, Math.round(largura * escala));
        int novaAltura = Math.max(1, Math.round(altura * escala));
        return Bitmap.createScaledBitmap(bitmap, novaLargura, novaAltura, true);
    }

    @NonNull
    private String descreverRegiao(RectF box) {
        if (box == null) return "em posição desconhecida";

        float larguraReferencia = (trackingOverlay != null && trackingOverlay.getWidth() > 0)
                ? trackingOverlay.getWidth() : previewWidth;
        float alturaReferencia = (trackingOverlay != null && trackingOverlay.getHeight() > 0)
                ? trackingOverlay.getHeight() : previewHeight;

        float centroX = (box.left + box.right) * 0.5f;
        float centroY = (box.top + box.bottom) * 0.5f;

        float xNormalizado = normalizarCoordenada(centroX, larguraReferencia, box.left, box.right);
        float yNormalizado = normalizarCoordenada(centroY, alturaReferencia, box.top, box.bottom);

        String horizontal;
        if (xNormalizado < 0.33f) horizontal = "esquerda";
        else if (xNormalizado > 0.67f) horizontal = "direita";
        else horizontal = "central";

        String vertical;
        if (yNormalizado < 0.33f) vertical = "superior";
        else if (yNormalizado > 0.67f) vertical = "inferior";
        else vertical = "central";

        if ("central".equals(vertical) && "central".equals(horizontal)) {
            return "no centro do quadro";
        }
        if ("central".equals(vertical)) {
            return "na região central à "
                    + ("esquerda".equals(horizontal) ? "esquerda" : "direita")
                    + " do quadro";
        }
        if ("central".equals(horizontal)) {
            return "na parte " + vertical + " central do quadro";
        }
        return "na parte " + vertical + " " + horizontal + " do quadro";
    }

    private float normalizarCoordenada(float coordenada, float dimensaoReferencia, float limiteA, float limiteB) {
        float maiorLimite = Math.max(limiteA, limiteB);
        float referencia = dimensaoReferencia;

        if (maiorLimite <= 1f && coordenada <= 1f) {
            referencia = 1f;
        }

        if (referencia <= 0f) {
            referencia = Math.max(1f, maiorLimite);
        }

        if (referencia < maiorLimite) {
            referencia = Math.max(1f, maiorLimite);
        }

        float normalizado = referencia <= 0f ? 0f : (coordenada / referencia);
        if (normalizado < 0f) normalizado = 0f;
        if (normalizado > 1f) normalizado = 1f;
        return normalizado;
    }

    private void solicitarDownloadQuadroAtual() {
        if (detectionPausedForExport) {
            Toast.makeText(this, R.string.operation_in_progress, Toast.LENGTH_SHORT).show();
            return;
        }
        interromperAudiosParaAcaoDePeca();
        falarImediato(getString(R.string.export_audio_warning));
        if (maoDetectadaRecentemente()) {
            aguardarSaidaMaoParaDownload();
            return;
        }
        pausarDeteccaoParaExportacao(this::salvarQuadroAtualComDeteccoes);
    }

    private boolean maoDetectadaRecentemente() {
        if (lastHandsSeenMs <= 0L) return false;
        long now = System.currentTimeMillis();
        return now - lastHandsSeenMs <= HAND_DOWNLOAD_COOLDOWN_MS;
    }

    private void aguardarSaidaMaoParaDownload() {
        if (handler == null) {
            return;
        }
        handler.postDelayed(() -> {
            if (detectionPausedForExport) {
                return;
            }
            if (maoDetectadaRecentemente()) {
                aguardarSaidaMaoParaDownload();
                return;
            }
            pausarDeteccaoParaExportacao(this::salvarQuadroAtualComDeteccoes);
        }, 100L);
    }

    private void pausarDeteccaoParaExportacao(@NonNull Runnable whenPaused) {
        capturarEstadoParaExportacao();
        detectionPausedForExport = true;
        detectionPaused = true;
        aguardarProcessamentoAtual(whenPaused);
    }

    private void aguardarProcessamentoAtual(@NonNull Runnable whenPaused) {
        if (handler == null) {
            whenPaused.run();
            return;
        }
        if (!isProcessingFrame) {
            whenPaused.run();
        } else {
            handler.postDelayed(() -> aguardarProcessamentoAtual(whenPaused), 16L);
        }
    }

    private void retomarDeteccaoAposExportacao() {
        detectionPaused = false;
        detectionPausedForExport = false;
        restaurarEstadoAposExportacao();
    }

    private void abortarExportacaoPorFalha() {
        if (detectionPausedForExport) {
            retomarDeteccaoAposExportacao();
        }
    }

    private void capturarEstadoParaExportacao() {
        exportFrozenBoxes.clear();
        exportFrozenLabels.clear();
        exportFrozenLastSeenMs.clear();
        exportFrozenTypes.clear();
        synchronized (frozenBoxes) {
            for (RectF box : frozenBoxes) {
                exportFrozenBoxes.add(new RectF(box));
            }
            exportFrozenLabels.addAll(frozenLabels);
            exportFrozenLastSeenMs.addAll(frozenLastSeenMs);
            exportFrozenTypes.addAll(frozenTypes);
        }
        exportStateCaptured = true;
    }

    private void restaurarEstadoAposExportacao() {
        if (!exportStateCaptured) {
            return;
        }
        long now = System.currentTimeMillis();
        synchronized (frozenBoxes) {
            frozenBoxes.clear();
            frozenLabels.clear();
            frozenLastSeenMs.clear();
            frozenTypes.clear();
            for (RectF box : exportFrozenBoxes) {
                frozenBoxes.add(new RectF(box));
                frozenLastSeenMs.add(now);
            }
            frozenLabels.addAll(exportFrozenLabels);
            for (int i = 0; i < exportFrozenTypes.size(); i++) {
                frozenTypes.add(exportFrozenTypes.get(i));
            }
        }
        exportFrozenBoxes.clear();
        exportFrozenLabels.clear();
        exportFrozenLastSeenMs.clear();
        exportFrozenTypes.clear();
        exportStateCaptured = false;
        if (trackingOverlay != null) {
            trackingOverlay.postInvalidate();
        }
    }

    private void salvarQuadroAtualComDeteccoes() {
        Bitmap frameCopy;
        synchronized (latestFrameLock) {
            frameCopy = latestFrameForExport != null
                    ? latestFrameForExport.copy(Bitmap.Config.ARGB_8888, false)
                    : null;
        }

        if (frameCopy == null) {
            Toast.makeText(this, R.string.image_view_not_ready, Toast.LENGTH_SHORT).show();
            abortarExportacaoPorFalha();
            return;
        }

        if (trackingOverlay == null) {
            Toast.makeText(this, R.string.image_error, Toast.LENGTH_SHORT).show();
            frameCopy.recycle();
            abortarExportacaoPorFalha();
            return;
        }

        int overlayWidth = trackingOverlay.getWidth();
        int overlayHeight = trackingOverlay.getHeight();

        if (overlayWidth <= 0 || overlayHeight <= 0) {
            Toast.makeText(this, R.string.image_view_not_ready, Toast.LENGTH_SHORT).show();
            frameCopy.recycle();
            abortarExportacaoPorFalha();
            return;
        }

        Bitmap combinedBitmap = null;
        Bitmap overlayViewBitmap = null;
        try {
            Bitmap frameForDisplay = ajustarOrientacaoParaExibicao(frameCopy, overlayWidth, overlayHeight);
            if (frameForDisplay != frameCopy) {
                frameCopy.recycle();
                frameCopy = frameForDisplay;
            }

            combinedBitmap = Bitmap.createBitmap(frameCopy.getWidth(), frameCopy.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas combinedCanvas = new Canvas(combinedBitmap);
            combinedCanvas.drawBitmap(frameCopy, 0, 0, null);

            overlayViewBitmap = Bitmap.createBitmap(overlayWidth, overlayHeight, Bitmap.Config.ARGB_8888);
            overlayViewBitmap.eraseColor(Color.TRANSPARENT);
            Canvas overlayCanvas = new Canvas(overlayViewBitmap);
            trackingOverlay.draw(overlayCanvas);

            Rect dest = new Rect(0, 0, frameCopy.getWidth(), frameCopy.getHeight());
            combinedCanvas.drawBitmap(overlayViewBitmap, null, dest, null);

            mostrarDialogoFormato(combinedBitmap);
        } catch (Exception e) {
            Log.e(TAG, "Failed to prepare image for saving", e);
            Toast.makeText(this, R.string.image_error, Toast.LENGTH_SHORT).show();
            if (combinedBitmap != null && !combinedBitmap.isRecycled()) {
                combinedBitmap.recycle();
            }
            abortarExportacaoPorFalha();
        } finally {
            if (overlayViewBitmap != null && !overlayViewBitmap.isRecycled()) {
                overlayViewBitmap.recycle();
            }
            if (frameCopy != null && !frameCopy.isRecycled()) {
                frameCopy.recycle();
            }
        }
    }

    @NonNull
    private Bitmap ajustarOrientacaoParaExibicao(@NonNull Bitmap bitmap, int overlayWidth, int overlayHeight) {
        int rotationToApply = normalizarRotacao(sensorOrientation);
        if (!orientacaoCompativel(bitmap, rotationToApply, overlayWidth, overlayHeight)) {
            rotationToApply = (rotationToApply + 90) % 360;
            if (!orientacaoCompativel(bitmap, rotationToApply, overlayWidth, overlayHeight)) {
                rotationToApply = (rotationToApply + 180) % 360;
            }
        }

        if (rotationToApply == 0) {
            return bitmap;
        }

        Matrix matrix = new Matrix();
        matrix.postRotate(rotationToApply);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    private boolean orientacaoCompativel(@NonNull Bitmap bitmap, int rotation, int overlayWidth, int overlayHeight) {
        if (overlayWidth <= 0 || overlayHeight <= 0) {
            return true;
        }
        int effectiveRotation = ((rotation % 360) + 360) % 360;
        boolean overlayPortrait = overlayHeight >= overlayWidth;
        boolean rotatedPortrait;
        if (effectiveRotation % 180 == 0) {
            rotatedPortrait = bitmap.getHeight() >= bitmap.getWidth();
        } else {
            rotatedPortrait = bitmap.getWidth() >= bitmap.getHeight();
        }
        return rotatedPortrait == overlayPortrait;
    }

    private int normalizarRotacao(int rotation) {
        int normalized = rotation % 360;
        if (normalized < 0) {
            normalized += 360;
        }
        return normalized;
    }

    private void mostrarDialogoFormato(@NonNull Bitmap combinedBitmap) {
        pendingExportChoiceBitmap = combinedBitmap;
        String[] options = {
                getString(R.string.format_png),
                getString(R.string.format_pdf),
                getString(R.string.format_share)
        };
        exportFormatDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.choose_format_title)
                .setItems(options, (dialog, which) -> {
                    interromperAudiosParaAcaoDePeca();
                    if (which == 0) {
                        aplicarFormatoExportacao(SaveFormat.PNG);
                    } else if (which == 1) {
                        aplicarFormatoExportacao(SaveFormat.PDF);
                    } else if (which == 2) {
                        aplicarCompartilhamentoExportacao();
                    } else {
                        limparSelecaoFormatoExportacao();
                    }
                })
                .setOnCancelListener(dialog -> {
                    interromperAudiosParaAcaoDePeca();
                    limparSelecaoFormatoExportacao();
                    Toast.makeText(this, R.string.save_cancelled, Toast.LENGTH_SHORT).show();
                })
                .create();
        exportFormatDialog.setOnDismissListener(dialog -> limparSelecaoFormatoExportacao());
        exportFormatDialog.show();
        falarEmFila(getString(R.string.export_format_voice_prompt), this::iniciarEscutaFormatoExportacao);
    }

    private void aplicarFormatoExportacao(@NonNull SaveFormat format) {
        Bitmap bitmap = pendingExportChoiceBitmap;
        pendingExportChoiceBitmap = null;
        if (exportFormatDialog != null) {
            exportFormatDialog.setOnDismissListener(null);
            exportFormatDialog.dismiss();
            exportFormatDialog = null;
        }
        if (bitmap == null) {
            abortarExportacaoPorFalha();
            return;
        }
        prepararSelecaoLocalSalvamento(bitmap, format);
    }

    private void aplicarCompartilhamentoExportacao() {
        Bitmap bitmap = pendingExportChoiceBitmap;
        pendingExportChoiceBitmap = null;
        if (exportFormatDialog != null) {
            exportFormatDialog.setOnDismissListener(null);
            exportFormatDialog.dismiss();
            exportFormatDialog = null;
        }
        if (bitmap == null) {
            abortarExportacaoPorFalha();
            return;
        }
        compartilharImagem(bitmap);
    }

    private void limparSelecaoFormatoExportacao() {
        if (listeningForExportFormat && speechRecognizer != null) {
            speechRecognizer.cancel();
        }
        listeningForExportFormat = false;
        pendingExportFormatRequest = false;
        isListeningName = false;
        if (pendingExportChoiceBitmap != null) {
            pendingExportChoiceBitmap.recycle();
            pendingExportChoiceBitmap = null;
            abortarExportacaoPorFalha();
        }
        exportFormatDialog = null;
    }

    private void prepararSelecaoLocalSalvamento(@NonNull Bitmap combinedBitmap, @NonNull SaveFormat format) {
        liberarBitmapPendente();
        pendingCombinedBitmap = combinedBitmap;
        pendingSaveFormat = format;

        String suggestedName = "detector_" + System.currentTimeMillis() +
                (format == SaveFormat.PNG ? ".png" : ".pdf");
        String mimeType = (format == SaveFormat.PNG) ? "image/png" : "application/pdf";

        iniciarSelecaoLocalSalvamento(suggestedName, mimeType);
    }

    private void iniciarSelecaoLocalSalvamento(@NonNull String suggestedName, @NonNull String mimeType) {
        if (createDocumentLauncher == null) {
            Log.w(TAG, "Create document launcher not initialized");
            Toast.makeText(this, R.string.image_error, Toast.LENGTH_SHORT).show();
            liberarBitmapPendente();
            abortarExportacaoPorFalha();
            return;
        }

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mimeType);
        intent.putExtra(Intent.EXTRA_TITLE, suggestedName);
        createDocumentLauncher.launch(intent);
    }

    private void onCreateDocumentResult(ActivityResult result) {
        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            Uri uri = result.getData().getData();
            if (uri != null) {
                processarSalvamentoEmUri(uri);
            } else if (pendingCombinedBitmap != null) {
                Toast.makeText(this, R.string.image_error, Toast.LENGTH_SHORT).show();
            }
        } else if (pendingCombinedBitmap != null) {
            interromperAudiosParaAcaoDePeca();
            Toast.makeText(this, R.string.save_cancelled, Toast.LENGTH_SHORT).show();
        }
        liberarBitmapPendente();
        retomarDeteccaoAposExportacao();
    }

    private void processarSalvamentoEmUri(@NonNull Uri uri) {
        if (pendingCombinedBitmap == null || pendingSaveFormat == null) {
            Toast.makeText(this, R.string.image_error, Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            if (pendingSaveFormat == SaveFormat.PNG) {
                salvarComoPng(uri);
            } else if (pendingSaveFormat == SaveFormat.PDF) {
                salvarComoPdf(uri);
            }
            String message = getString(R.string.image_saved, uri.toString());
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Log.e(TAG, "Failed to save exported image", e);
            Toast.makeText(this, R.string.image_error, Toast.LENGTH_SHORT).show();
        }
    }

    private void salvarComoPng(@NonNull Uri uri) throws IOException {
        if (pendingCombinedBitmap == null) {
            throw new IOException("No bitmap to save");
        }
        try (OutputStream outputStream = getContentResolver().openOutputStream(uri)) {
            if (outputStream == null) {
                throw new IOException("Unable to open output stream");
            }
            if (!pendingCombinedBitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)) {
                throw new IOException("Bitmap compression failed");
            }
            outputStream.flush();
        }
    }

    private void salvarComoPdf(@NonNull Uri uri) throws IOException {
        if (pendingCombinedBitmap == null) {
            throw new IOException("No bitmap to save");
        }

        PdfDocument pdfDocument = new PdfDocument();
        try (OutputStream outputStream = getContentResolver().openOutputStream(uri)) {
            if (outputStream == null) {
                throw new IOException("Unable to open output stream");
            }
            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(
                    pendingCombinedBitmap.getWidth(),
                    pendingCombinedBitmap.getHeight(),
                    1
            ).create();
            PdfDocument.Page page = pdfDocument.startPage(pageInfo);
            Canvas canvas = page.getCanvas();
            canvas.drawBitmap(pendingCombinedBitmap, 0, 0, null);
            pdfDocument.finishPage(page);
            pdfDocument.writeTo(outputStream);
        } finally {
            pdfDocument.close();
        }
    }

    private void liberarBitmapPendente() {
        if (pendingCombinedBitmap != null && !pendingCombinedBitmap.isRecycled()) {
            pendingCombinedBitmap.recycle();
        }
        pendingCombinedBitmap = null;
        pendingSaveFormat = null;
    }

    private void compartilharImagem(@NonNull Bitmap bitmap) {
        File cacheDir = new File(getCacheDir(), "shared");
        if (!cacheDir.exists() && !cacheDir.mkdirs()) {
            Toast.makeText(this, R.string.image_error, Toast.LENGTH_SHORT).show();
            if (!bitmap.isRecycled()) {
                bitmap.recycle();
            }
            abortarExportacaoPorFalha();
            return;
        }
        File imageFile = new File(cacheDir, "arpiagrama_share_" + System.currentTimeMillis() + ".png");
        try (FileOutputStream outputStream = new FileOutputStream(imageFile)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)) {
                throw new IOException("Bitmap compression failed");
            }
            outputStream.flush();
        } catch (IOException e) {
            Log.e(TAG, "Failed to share exported image", e);
            Toast.makeText(this, R.string.image_error, Toast.LENGTH_SHORT).show();
            if (!bitmap.isRecycled()) {
                bitmap.recycle();
            }
            abortarExportacaoPorFalha();
            return;
        }

        if (!bitmap.isRecycled()) {
            bitmap.recycle();
        }

        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", imageFile);
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("image/png");
        shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        pendingShareReturn = true;
        try {
            startActivity(Intent.createChooser(shareIntent, getString(R.string.export_image)));
        } catch (Exception e) {
            Log.e(TAG, "No activity found to share image", e);
            pendingShareReturn = false;
            Toast.makeText(this, R.string.image_error, Toast.LENGTH_SHORT).show();
            abortarExportacaoPorFalha();
        }
    }

    private interface CameraSelectorStrategy {
        String select(CameraManager manager) throws CameraAccessException;
    }

    private static final class BackCameraFirstSelector implements CameraSelectorStrategy {
        @Override
        public String select(CameraManager manager) throws CameraAccessException {
            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics ch = manager.getCameraCharacteristics(id);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    return id;
                }
            }
            String[] ids = manager.getCameraIdList();
            return ids.length > 0 ? ids[0] : null;
        }
    }

    private static final class CameraFragmentFactory {
        private CameraFragmentFactory() {}

        static CameraConnectionFragment create(CameraConnectionFragment.ConnectionCallback callback,
                                               Activity activity) {
            return CameraConnectionFragment.newInstance(
                    callback,
                    (ImageReader.OnImageAvailableListener) activity,
                    R.layout.camera_fragment,
                    DEFAULT_PREVIEW_SIZE
            );
        }
    }

    private String selecionarCameraPadrao(CameraManager manager) {
        try {
            return cameraSelector.select(manager);
        } catch (CameraAccessException e) {
            Log.e(TAG, "Erro ao selecionar cameraId padrão", e);
            return null;
        }
    }

    protected void configurarFragmento() {
        final CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        String cameraId = selecionarCameraPadrao(manager);

        CameraConnectionFragment camera2Fragment = CameraFragmentFactory.create(
                new CameraConnectionFragment.ConnectionCallback() {
                    @Override
                    public void onPreviewSizeChosen(final Size size, final int rotation) {
                        previewHeight = size.getHeight();
                        previewWidth = size.getWidth();

                        final float textSizePx = TypedValue.applyDimension(
                                TypedValue.COMPLEX_UNIT_DIP, TEXT_SIZE_DIP,
                                getResources().getDisplayMetrics());
                        borderedText = new BorderedText(textSizePx);
                        borderedText.setTypeface(Typeface.MONOSPACE);

                        tracker = new MultiBoxTracker(MainActivity.this);

                        int cropSize = TF_OD_API_INPUT_SIZE;
                        sensorOrientation = rotation - obterOrientacaoTela();

                        detectionRoi = calcularRoiMesa(previewWidth, previewHeight);
                        roiPaint.setStyle(Paint.Style.STROKE);
                        roiPaint.setColor(Color.GRAY);
                        roiPaint.setStrokeWidth(TypedValue.applyDimension(
                                TypedValue.COMPLEX_UNIT_DIP, 2f, getResources().getDisplayMetrics()));
                        roiPaint.setAntiAlias(true);
                        roiLegendTextPaint.setColor(Color.WHITE);
                        roiLegendTextPaint.setTextSize(TypedValue.applyDimension(
                                TypedValue.COMPLEX_UNIT_DIP, 12f, getResources().getDisplayMetrics()));
                        roiLegendTextPaint.setAntiAlias(true);
                        roiLegendTextPaint.setFakeBoldText(true);

                        roiLegendBackgroundPaint.setStyle(Paint.Style.FILL);
                        roiLegendBackgroundPaint.setColor(Color.argb(180, 20, 20, 20));
                        roiLegendBackgroundPaint.setAntiAlias(true);

                        roiActorLegendPaint.setStyle(Paint.Style.FILL);
                        roiActorLegendPaint.setColor(Color.parseColor("#8B4513"));
                        roiUseCaseLegendPaint.setStyle(Paint.Style.FILL);
                        roiUseCaseLegendPaint.setColor(Color.parseColor("#0066FF"));
                        roiRelationLegendPaint.setStyle(Paint.Style.FILL);
                        roiRelationLegendPaint.setColor(Color.parseColor("#C8A2C8"));

                        rgbFrameBitmap = Bitmap.createBitmap(previewWidth, previewHeight, Bitmap.Config.ARGB_8888);
                        croppedBitmap = Bitmap.createBitmap(cropSize, cropSize, Bitmap.Config.ARGB_8888);

                        frameToCropTransform = ImageUtils.getTransformationMatrix(
                                previewWidth, previewHeight,
                                cropSize, cropSize,
                                sensorOrientation, MAINTAIN_ASPECT);

                        cropToFrameTransform = new Matrix();
                        frameToCropTransform.invert(cropToFrameTransform);

                        trackingOverlay = findViewById(R.id.tracking_overlay);
                        trackingOverlay.addCallback((Canvas canvas) -> {
                            tracker.draw(canvas);
                            desenharRoi(canvas);
                        });

                        tracker.setFrameConfiguration(previewWidth, previewHeight, sensorOrientation);
                    }
                },
                this);

        camera2Fragment.setCamera(cameraId);
        Fragment fragment = camera2Fragment;
        getSupportFragmentManager().beginTransaction().replace(R.id.container, fragment).commit();
    }

    @Override
    public void onImageAvailable(ImageReader reader) {
        if (previewWidth == 0 || previewHeight == 0) return;
        if (rgbBytes == null) rgbBytes = new int[previewWidth * previewHeight];

        try {
            final Image image = reader.acquireLatestImage();
            if (image == null) return;

            if (detectionPaused) {
                image.close();
                return;
            }

            if (isProcessingFrame) {
                image.close();
                return;
            }
            isProcessingFrame = true;
            final Image.Plane[] planes = image.getPlanes();
            preencherBytes(planes, yuvBytes);
            yRowStride = planes[0].getRowStride();
            final int uvRowStride = planes[1].getRowStride();
            final int uvPixelStride = planes[1].getPixelStride();

            imageConverter = () -> ImageUtils.convertYUV420ToARGB8888(
                    yuvBytes[0], yuvBytes[1], yuvBytes[2],
                    previewWidth, previewHeight,
                    yRowStride, uvRowStride, uvPixelStride, rgbBytes
            );

            postInferenceCallback = () -> {
                image.close();
                isProcessingFrame = false;
            };

            processarImagem();

        } catch (final Exception e) {
            Log.e("MainActivity", "onImageAvailable error", e);
        }
    }

    // ====== A partir daqui, fluxo de detecção/nomeação ======

    public void processarImagem() {

        imageConverter.run();
        if (rgbFrameBitmap == null) {
            if (postInferenceCallback != null) postInferenceCallback.run();
            return;
        }
        emitirMensagemBoasVindas();
        rgbFrameBitmap.setPixels(rgbBytes, 0, previewWidth, 0, 0, previewWidth, previewHeight);

        Bitmap frameParaDeteccao = aplicarRecorteRoi(rgbFrameBitmap);



        List<RectF> handRegions = detectarMaos(frameParaDeteccao);
        atualizarMaos(handRegions);
        List<RectF> handSnapshot = copiarMaos();
        verificarPersistenciaMaos(handSnapshot);
/*
        ObjectDetectorHelper.ResultBundle resultBundle = objectDetectorHelper.detectarImagem(frameParaDeteccao);
        if (resultBundle == null) {
            if (postInferenceCallback != null) postInferenceCallback.run();
            return;
        }

        List<Recognition> recognitions = new ArrayList<>();
        List<ObjectDetectionResult> detectionResults = resultBundle.obterResultados();
        for (ObjectDetectionResult singleResult : detectionResults) {
            for (Detection d : singleResult.detections()) {
                float confidence = 0f; String label = "";
                for (Category c : d.categories()) {
                    if (c.score() > confidence) { confidence = c.score(); label = c.categoryName(); }
                }
                RectF rawBox = d.boundingBox();
                RectF roiBox = limitarParaRoi(rawBox);
                if (confidence > MIN_CONFIDENCE && roiBox != null && !sobrepoeMao(roiBox, handSnapshot)) {
                    String tipo = determinarTipoPeca(label);
                    recognitions.add(new Recognition(label, confidence, "id", roiBox, null, tipo, false, false));
                }
            }
        }
*/



        if (yoloDetector == null) {
            if (postInferenceCallback != null) postInferenceCallback.run();
            return;
        }

        List<YoloV8TfliteDetector.Det> dets = yoloDetector.detect(frameParaDeteccao);

        List<Recognition> recognitions = new ArrayList<>();
        for (YoloV8TfliteDetector.Det d : dets) {
            float confidence = d.score;
            String label = d.label;

            RectF rawBox = d.box;                 // já está na ROI (pixels)
            RectF roiBox = limitarParaRoi(rawBox);

            if (confidence > MIN_CONFIDENCE && roiBox != null && !sobrepoeMao(roiBox, handSnapshot)) {
                String tipo = determinarTipoPeca(label); // ou use d.classId se preferir
                recognitions.add(new Recognition(label, confidence, "id", roiBox, null, tipo, false, false));
            }
        }
        long now = System.currentTimeMillis();

        // 1) presença de peças congeladas
        Map<String, Integer> frozenTypeCounts = new HashMap<>();
        for (String tipo : frozenTypes) {
            if (tipo == null) continue;
            frozenTypeCounts.put(tipo, frozenTypeCounts.getOrDefault(tipo, 0) + 1);
        }
        RectF pendingBox = obterCaixaPecaEmDefinicao();
        boolean[] recognitionUsed = new boolean[recognitions.size()];
        for (int i = 0; i < frozenBoxes.size(); i++) {
            RectF f = frozenBoxes.get(i);
            String frozenType = (i < frozenTypes.size()) ? frozenTypes.get(i) : null;
            boolean seen = false;
            if (sobrepoeMao(f, handSnapshot)) {
                seen = true;
            } else {
                for (int rIndex = 0; rIndex < recognitions.size(); rIndex++) {
                    if (recognitionUsed[rIndex]) continue;
                    Recognition r = recognitions.get(rIndex);
                    RectF loc = r.getLocation();
                    if (loc == null) continue;
                    if (i != pendingNameIndex && pendingBox != null && sobrepoePecaEmDefinicao(loc, pendingBox, PENDING_PIECE_EXCLUSION_IOU)) {
                        continue;
                    }
                    if (calcularIou(loc, f) >= PRESENCE_IOU_THR || centroProximoComFracao(f, loc, PRESENCE_CENTER_TOL_FRAC)) {
                        seen = true;
                        recognitionUsed[rIndex] = true;
                        atualizarCaixaCongelada(i, loc);
                        break;
                    }
                }
            }
            if (!seen && frozenType != null && frozenTypeCounts.getOrDefault(frozenType, 0) == 1) {
                int melhorIndice = encontrarMelhorReconhecimentoPorTipo(recognitions, frozenType, f, recognitionUsed, pendingBox);
                if (melhorIndice >= 0) {
                    RectF loc = recognitions.get(melhorIndice).getLocation();
                    if (loc != null && !sobrepoeAlgumCongelado(loc, 0.2f, i)) {
                        seen = true;
                        recognitionUsed[melhorIndice] = true;
                        atualizarCaixaCongelada(i, loc);
                    }
                }
            }
            if (seen) {
                if (i < frozenLastSeenMs.size()) frozenLastSeenMs.set(i, now);
                else frozenLastSeenMs.add(now);
            }
        }

        // 2) candidatos novos (sem colidir com congelados)
        List<Recognition> stableCandidates = new ArrayList<>();
        for (Recognition r : recognitions) {
            if (r.getLocation() == null) continue;
            if (sobrepoeMao(r.getLocation(), handSnapshot)) continue;
            if (!sobrepoeAlgumCongelado(r.getLocation(), 0.5f)) stableCandidates.add(r);
        }

        if (interactionState == InteractionState.AGUARDANDO_PECA) {
            // 3) reposicionamento (se solicitado)
            tentarReposicionamento(stableCandidates, now);

            // 4) estabilidade (uma peça por vez)
            List<Recognition> namingCandidates = new ArrayList<>();
            for (Recognition candidate : stableCandidates) {
                if (candidate == null) continue;
                String tipo = candidate.getType();
                if (ehClasseNd(tipo) || ehClasseNd(candidate.getTitle())) {
                    continue;
                }
                if (pendingRelocationType != null && tipo != null && tipo.equals(pendingRelocationType)) {
                    continue;
                }
                namingCandidates.add(candidate);
            }

            int detectedCount = namingCandidates.size();
            if (detectedCount >= 2) {
                if (multiPieceDetectedSinceMs == 0L) {
                    multiPieceDetectedSinceMs = now;
                } else if (now - multiPieceDetectedSinceMs >= MULTI_PIECE_WARN_THRESHOLD_MS) {
                    if (!multiPieceWarningSent || now - multiPieceLastWarningMs >= MULTI_PIECE_REPEAT_INTERVAL_MS) {
                        String msg = "Detectei mais de uma peça. Deixe apenas uma peça na área de leitura para continuar.";
                        interromperAudiosParaAcaoDePeca();
                        falarEmFila(msg);
                        runOnUiThread(() ->
                                android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()
                        );
                        multiPieceWarningSent = true;
                        multiPieceLastWarningMs = now;
                    }
                }
                lastBox = null;
                lastStableLabel = null;
                stableSinceMs = 0L;
            } else {
                multiPieceDetectedSinceMs = 0L;
                multiPieceWarningSent = false;
                multiPieceLastWarningMs = 0L;
                if (detectedCount == 1) {
                    Recognition top = melhorReconhecimento(namingCandidates);
                    if (top != null && top.getLocation() != null) {
                        RectF curr = top.getLocation();
                        String rawLabel = obterRotuloReconhecimento(top);
                        if (rawLabel == null) rawLabel = "";
                        if (lastBox == null || lastStableLabel == null || !lastStableLabel.equals(rawLabel)) {
                            lastBox = new RectF(curr);
                            lastStableLabel = rawLabel;
                            stableSinceMs = now;
                        } else if (centroProximoSuficiente(lastBox, curr)) {
                            if (stableSinceMs == 0L) stableSinceMs = now;
                            if ((now - stableSinceMs) >= STABILITY_MS && !dialogoNomeAberto()) {
                                interromperAudiosParaAcaoDePeca();
                                interactionState = InteractionState.PECA_TRAVADA;
                                iniciarCongelamento(curr, rawLabel);
                                lastBox = null;
                                lastStableLabel = null;
                                stableSinceMs = 0L;
                            }
                        } else {
                            lastBox = new RectF(curr);
                            lastStableLabel = rawLabel;
                            stableSinceMs = now;
                        }
                    } else {
                        lastBox = null;
                        lastStableLabel = null;
                        stableSinceMs = 0L;
                    }
                } else {
                    lastBox = null;
                    lastStableLabel = null;
                    stableSinceMs = 0L;
                }
            }
        } else {
            lastBox = null;
            lastStableLabel = null;
            stableSinceMs = 0L;
            multiPieceDetectedSinceMs = 0L;
            multiPieceWarningSent = false;
            multiPieceLastWarningMs = 0L;
        }

        // 4) render
        List<Recognition> combined = new ArrayList<>();
        for (int i = 0; i < frozenBoxes.size(); i++) {
            RectF f = frozenBoxes.get(i);
            String lbl = frozenLabels.get(i);
            String disp = (lbl == null || lbl.isEmpty()) ? "Peça" : lbl;
            String tipo = (i < frozenTypes.size()) ? frozenTypes.get(i) : null;
            boolean definido = lbl != null && !lbl.isEmpty();
            boolean sendoDefinido = pendingNameIndex == i;
            combined.add(new Recognition(disp, 1.0f, "frozen", new RectF(f), disp, tipo, definido, sendoDefinido));
        }
        if (interactionState == InteractionState.AGUARDANDO_PECA) {
            List<Recognition> filtered = new ArrayList<>();
            for (Recognition r : recognitions) {
                if (r.getLocation() == null) continue;
                if (sobrepoeMao(r.getLocation(), handSnapshot)) continue;
                if (!sobrepoeAlgumCongelado(r.getLocation(), 0.5f)) filtered.add(r);
            }
            combined.addAll(filtered);
        }

        tracker.trackResults(combined, 10);
        trackingOverlay.postInvalidate();

        synchronized (latestFrameLock) {
            if (rgbFrameBitmap != null) {
                if (latestFrameForExport == null
                        || latestFrameForExport.getWidth() != rgbFrameBitmap.getWidth()
                        || latestFrameForExport.getHeight() != rgbFrameBitmap.getHeight()) {
                    latestFrameForExport = Bitmap.createBitmap(
                            rgbFrameBitmap.getWidth(),
                            rgbFrameBitmap.getHeight(),
                            Bitmap.Config.ARGB_8888
                    );
                }
                Canvas copyCanvas = new Canvas(latestFrameForExport);
                copyCanvas.drawBitmap(rgbFrameBitmap, 0, 0, null);
            }
        }

        if (postInferenceCallback != null) postInferenceCallback.run();
    }

    private List<RectF> detectarMaos(Bitmap frame) {
        if (handDetectorHelper == null || frame == null) {
            return Collections.emptyList();
        }
        List<RectF> maos = handDetectorHelper.detectarMaos(frame);
        return maos == null ? Collections.emptyList() : maos;
    }

    private void atualizarMaos(List<RectF> maos) {
        synchronized (detectedHandBoxes) {
            detectedHandBoxes.clear();
            if (maos == null) {
                return;
            }
            for (RectF mao : maos) {
                if (mao != null) {
                    detectedHandBoxes.add(new RectF(mao));
                }
            }
        }
    }

    private List<RectF> copiarMaos() {
        synchronized (detectedHandBoxes) {
            List<RectF> copia = new ArrayList<>(detectedHandBoxes.size());
            for (RectF mao : detectedHandBoxes) {
                if (mao != null) {
                    copia.add(new RectF(mao));
                }
            }
            return copia;
        }
    }

    private void verificarPersistenciaMaos(List<RectF> handSnapshot) {
        long now = System.currentTimeMillis();
        boolean hasHands = handSnapshot != null && !handSnapshot.isEmpty();

        if (hasHands) {
            lastHandsSeenMs = now;
            if (handsSeenSinceMs == 0L) {
                handsSeenSinceMs = now;
                handWarningShown = false;
            } else if (!handWarningShown && now - handsSeenSinceMs >= HAND_PERSISTENCE_MS) {
                handWarningShown = true;
                falarEmFila(HAND_PERSISTENCE_MESSAGE);
                runOnUiThread(() ->
                        android.widget.Toast.makeText(this, HAND_PERSISTENCE_MESSAGE, android.widget.Toast.LENGTH_SHORT).show()
                );
            }
        } else {
            handsSeenSinceMs = 0L;
            handWarningShown = false;
        }
    }

    private boolean sobrepoeMao(RectF caixa, List<RectF> maoSnapshot) {
        if (caixa == null || maoSnapshot == null || maoSnapshot.isEmpty()) return false;
        for (RectF mao : maoSnapshot) {
            if (mao == null) continue;
            float interW = Math.max(0f, Math.min(caixa.right, mao.right) - Math.max(caixa.left, mao.left));
            float interH = Math.max(0f, Math.min(caixa.bottom, mao.bottom) - Math.max(caixa.top, mao.top));
            float inter = interW * interH;
            float areaA = Math.max(0f, caixa.width()) * Math.max(0f, caixa.height());
            float areaB = Math.max(0f, mao.width()) * Math.max(0f, mao.height());
            float union = areaA + areaB - inter;
            if (union > 0f && inter / union >= HAND_OVERLAP_IOU_THR) {
                return true;
            }
        }
        return false;
    }

    private void interromperAudiosParaAcaoDePeca() {
        if (speechController != null) {
            speechController.stopAll();
        }
    }

    private void mostrarToastCurto(@StringRes int resId) {
        Toast.makeText(this, resId, Toast.LENGTH_SHORT).show();
    }

    private void mostrarFalhaReconhecimentoVoz() {
        mostrarToastCurto(R.string.voice_start_error);
    }

    private String formatarTipoPeca(String tipo) {
        if (tipo == null || tipo.trim().isEmpty()) {
            return "peça";
        }
        return tipo.trim();
    }

    private String mensagemPecaRemovida(String tipo) {
        String tipoFormatado = formatarTipoPeca(tipo);
        if ("peça".equals(tipoFormatado)) {
            return "Peça removida do quadro.";
        }
        return "Peça " + tipoFormatado + " removida do quadro.";
    }

    private void falarImediato(String texto) {
        if (speechController != null) {
            speechController.speakImmediate(texto);
        }
    }
    private void falarEmFila(String texto, Runnable onDone) {
        if (speechController != null) {
            speechController.speakQueued(texto, onDone);
        } else if (onDone != null) {
            onDone.run();
        }
    }
    private void falarEmFila(String texto) {
        if (speechController != null) {
            speechController.speakQueued(texto);
        }
    }

    private void configurarReconhecimentoVoz() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(TAG, "Reconhecimento de voz não está disponível neste dispositivo.");
            return;
        }
        speechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                isListeningName = true;
            }

            @Override
            public void onBeginningOfSpeech() {}

            @Override
            public void onRmsChanged(float rmsdB) {}

            @Override
            public void onBufferReceived(byte[] buffer) {}

            @Override
            public void onEndOfSpeech() {
                isListeningName = false;
            }

            @Override
            public void onError(int error) {
                isListeningName = false;
                cancelNameListeningTimeout();
                if (ignoreNextNameError) {
                    ignoreNextNameError = false;
                    return;
                }
                boolean confirmationAttempt = awaitingNameConfirmation || listeningForNameConfirmation;
                boolean interactiveAttempt = listeningForInteractiveDescription;
                boolean removalAttempt = listeningForRemovalDecision;
                boolean exportAttempt = listeningForExportFormat;
                listeningForInteractiveDescription = false;
                pendingInteractiveDescriptionRequest = false;
                listeningForNameConfirmation = false;
                listeningForRemovalDecision = false;
                listeningForExportFormat = false;
                if (confirmationAttempt) {
                    return;
                }
                awaitingNameConfirmation = false;
                lastSpokenName = null;
                cancelConfirmationNoResponsePrompt();
                if (pendingVoiceInputTarget != null) {
                    if (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        repetirPromptNome();
                        return;
                    }
                    mostrarToastCurto(R.string.voice_listen_error_name);
                    handler.postDelayed(() -> iniciarEscutaNomeComPermissao(pendingVoiceInputTarget), 400);
                } else if (interactiveAttempt) {
                    mostrarToastCurto(R.string.voice_listen_error_command);
                } else if (removalAttempt) {
                    mostrarToastCurto(R.string.voice_listen_error_decision);
                } else if (exportAttempt) {
                    mostrarToastCurto(R.string.voice_listen_error_format);
                    repetirPromptFormatoExportacao();
                }
            }

            @Override
            public void onResults(Bundle results) {
                isListeningName = false;
                cancelNameListeningTimeout();
                List<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    if (listeningForExportFormat) {
                        processarFormatoExportacao(matches);
                    } else if (listeningForNameConfirmation) {
                        processarConfirmacaoNome(matches);
                    } else if (listeningForRemovalDecision) {
                        processarDecisaoRemocao(matches);
                    } else if (pendingVoiceInputTarget != null) {
                        processarNomeFalado(matches);
                    } else if (listeningForInteractiveDescription && comandoDescricaoInterativa(matches)) {
                        solicitarDescricaoContextual();
                    }
                } else if (listeningForExportFormat) {
                    processarFormatoExportacao(matches);
                }
                if (!awaitingNameConfirmation) {
                    pendingVoiceInputTarget = null;
                }
                listeningForInteractiveDescription = false;
                pendingInteractiveDescriptionRequest = false;
            }

            @Override
            public void onPartialResults(Bundle partialResults) {}

            @Override
            public void onEvent(int eventType, Bundle params) {}
        });
    }

    private void iniciarNomePorVoz(EditText input) {
        if (input == null) return;
        pendingInteractiveDescriptionRequest = false;
        resetNameVoiceState();
        if (speechRecognizer == null || speechRecognizerIntent == null) {
            falarEmFila("Reconhecimento de voz não está disponível.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingVoiceInputTarget = input;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION_CODE);
            return;
        }
        iniciarEscutaNomeComPermissao(input, true);
    }

    private void processarNomeFalado(List<String> matches) {
        if (pendingVoiceInputTarget == null || matches == null || matches.isEmpty()) return;
        String spoken = matches.get(0);
        pendingVoiceInputTarget.setText(spoken);
        pendingVoiceInputTarget.setSelection(spoken.length());
        lastSpokenName = spoken;
        awaitingNameConfirmation = true;
        falarEmFila(getString(R.string.voice_confirmation_prompt, spoken), this::iniciarEscutaConfirmacaoNome);
    }

    private void processarConfirmacaoNome(List<String> matches) {
        listeningForNameConfirmation = false;
        if (matches == null || matches.isEmpty()) {
            return;
        }
        cancelConfirmationNoResponsePrompt();
        EditText targetInput = pendingVoiceInputTarget;
        String resposta = matches.get(0).toLowerCase(Locale.getDefault());
        if (resposta.contains("sim")) {
            aplicarNomeConfirmado();
        } else if (resposta.contains("não") || resposta.contains("nao")) {
            awaitingNameConfirmation = false;
            lastSpokenName = null;
            if (targetInput != null) {
                targetInput.setText("");
            }
            falarEmFila(getString(R.string.voice_prompt_retry), () -> iniciarEscutaNomeComPermissao(targetInput));
        } else {
            awaitingNameConfirmation = false;
            lastSpokenName = null;
            if (targetInput != null) {
                targetInput.setText("");
            }
            falarEmFila(getString(R.string.voice_prompt_timeout), () -> iniciarEscutaNomeComPermissao(targetInput));
        }
    }

    private void aplicarNomeConfirmado() {
        cancelConfirmationNoResponsePrompt();
        if (pendingVoiceInputTarget == null || lastSpokenName == null) {
            awaitingNameConfirmation = false;
            return;
        }
        String name = lastSpokenName.trim();
        pendingVoiceInputTarget.setText(name);
        pendingVoiceInputTarget.setSelection(name.length());
        awaitingNameConfirmation = false;
        lastSpokenName = null;
        nomeDefinidoPorVoz = true;
        falarEmFila("Nome confirmado: " + name);
        confirmarNomeDialogoAtual();
    }

    private void iniciarEscutaNomeComPermissao(EditText input) {
        iniciarEscutaNomeComPermissao(input, true);
    }

    private void iniciarEscutaNomeComPermissao(EditText input, boolean falarPrompt) {
        if (input == null) return;
        if (speechRecognizer == null || speechRecognizerIntent == null) return;
        pararEscutaVoz();
        pendingVoiceInputTarget = input;
        Runnable iniciarEscuta = () -> {
            if (speechRecognizer == null || speechRecognizerIntent == null) return;
            try {
                isListeningName = true;
                speechRecognizer.startListening(speechRecognizerIntent);
                agendarEncerramentoEscuta();
                agendarTimeoutNome();
            } catch (Exception e) {
                Log.e(TAG, "Erro ao iniciar reconhecimento de voz", e);
                mostrarFalhaReconhecimentoVoz();
                pendingVoiceInputTarget = null;
            }
        };
        try {
            if (falarPrompt && !namePromptSpoken) {
                String prompt = getString(R.string.voice_prompt_name);
                Toast.makeText(this, prompt, Toast.LENGTH_SHORT).show();
                falarEmFila(prompt, iniciarEscuta);
                namePromptSpoken = true;
            } else {
                iniciarEscuta.run();
            }
        } catch (Exception e) {
            Log.e(TAG, "Erro ao iniciar reconhecimento de voz", e);
            mostrarFalhaReconhecimentoVoz();
            pendingVoiceInputTarget = null;
        }
    }

    private void confirmarNomeDialogoAtual() {
        if (currentNameDialog == null) return;
        Button okButton = currentNameDialog.getButton(AlertDialog.BUTTON_POSITIVE);
        if (okButton != null) {
            okButton.performClick();
        }
    }

    private void iniciarEscutaConfirmacaoNome() {
        if (pendingVoiceInputTarget == null) return;
        if (speechRecognizer == null || speechRecognizerIntent == null) return;
        listeningForNameConfirmation = true;
        awaitingNameConfirmation = true;
        try {
            isListeningName = true;
            speechRecognizer.startListening(speechRecognizerIntent);
            agendarEncerramentoEscuta();
            agendarChecagemConfirmacaoSemResposta();
        } catch (Exception e) {
            Log.e(TAG, "Erro ao iniciar confirmação do nome", e);
            mostrarFalhaReconhecimentoVoz();
            listeningForNameConfirmation = false;
            awaitingNameConfirmation = false;
        }
    }

    private void iniciarEscutaDescricaoInterativa() {
        if (speechRecognizer == null || speechRecognizerIntent == null) {
            return;
        }
        if (dialogoNomeAberto() || interactionState == InteractionState.DEFININDO_PECA) {
            return;
        }
        if (contextDescriptionManager != null && contextDescriptionManager.isRequestInProgress()) {
            return;
        }
        pendingVoiceInputTarget = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingInteractiveDescriptionRequest = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION_CODE);
            return;
        }
        iniciarEscutaDescricaoInterativaComPermissao();
    }

    private void iniciarEscutaDescricaoInterativaComPermissao() {
        if (speechRecognizer == null || speechRecognizerIntent == null) return;
        pararEscutaVoz();
        listeningForInteractiveDescription = true;
        pendingInteractiveDescriptionRequest = false;
        try {
            isListeningName = true;
            speechRecognizer.startListening(speechRecognizerIntent);
            agendarEncerramentoEscuta();
        } catch (Exception e) {
            Log.e(TAG, "Erro ao iniciar comando de descrição interativa", e);
            listeningForInteractiveDescription = false;
        }
    }

    private void iniciarEscutaFormatoExportacao() {
        if (speechRecognizer == null || speechRecognizerIntent == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingExportFormatRequest = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION_CODE);
            return;
        }
        iniciarEscutaFormatoExportacaoComPermissao();
    }

    private void iniciarEscutaFormatoExportacaoComPermissao() {
        if (speechRecognizer == null || speechRecognizerIntent == null) return;
        pararEscutaVoz();
        listeningForExportFormat = true;
        pendingExportFormatRequest = false;
        try {
            isListeningName = true;
            speechRecognizer.startListening(speechRecognizerIntent);
            agendarEncerramentoEscuta();
        } catch (Exception e) {
            Log.e(TAG, "Erro ao iniciar seleção de formato por voz", e);
            listeningForExportFormat = false;
        }
    }

    private void pararEscutaVoz() {
        if (speechRecognizer != null && isListeningName) {
            speechRecognizer.cancel();
        }
        isListeningName = false;
        listeningForInteractiveDescription = false;
        listeningForNameConfirmation = false;
        listeningForRemovalDecision = false;
        listeningForExportFormat = false;
        cancelConfirmationNoResponsePrompt();
        cancelNameListeningTimeout();
        cancelListeningWindowTimeout();
    }

    private void resetNameVoiceState() {
        cancelConfirmationNoResponsePrompt();
        cancelNameListeningTimeout();
        awaitingNameConfirmation = false;
        listeningForNameConfirmation = false;
        lastSpokenName = null;
        pendingVoiceInputTarget = null;
        namePromptSpoken = false;
        nomeDefinidoPorVoz = false;
    }

    private boolean comandoDescricaoInterativa(List<String> matches) {
        if (matches == null || matches.isEmpty()) {
            return false;
        }
        for (String spoken : matches) {
            if (spoken == null) continue;
            String normalized = Normalizer.normalize(spoken, Normalizer.Form.NFD)
                    .replaceAll("\\p{M}+", "")
                    .toLowerCase(Locale.ROOT)
                    .trim();
            if (normalized.contains(INTERACTIVE_DESCRIPTION_COMMAND)) {
                return true;
            }
        }
        return false;
    }

    private void processarFormatoExportacao(List<String> matches) {
        listeningForExportFormat = false;
        if (matches == null || matches.isEmpty()) {
            repetirPromptFormatoExportacao();
            return;
        }
        for (String spoken : matches) {
            if (spoken == null) continue;
            String normalized = Normalizer.normalize(spoken, Normalizer.Form.NFD)
                    .replaceAll("\\p{M}+", "")
                    .toLowerCase(Locale.ROOT)
                    .trim();
            String compact = normalized.replaceAll("[^a-z0-9]", "");
            if (compact.contains("png")) {
                aplicarFormatoExportacao(SaveFormat.PNG);
                return;
            }
            if (compact.contains("pdf")) {
                aplicarFormatoExportacao(SaveFormat.PDF);
                return;
            }
            if (compact.contains("compartilh") || compact.contains("share")) {
                aplicarCompartilhamentoExportacao();
                return;
            }
        }
        repetirPromptFormatoExportacao();
    }

    private void repetirPromptFormatoExportacao() {
        if (exportFormatDialog == null || !exportFormatDialog.isShowing()) {
            return;
        }
        falarEmFila(getString(R.string.export_format_voice_retry), this::iniciarEscutaFormatoExportacao);
    }

    private void agendarChecagemConfirmacaoSemResposta() {
        if (handler == null) return;
        cancelConfirmationNoResponsePrompt();
        confirmationNoResponseRunnable = () -> {
            if (awaitingNameConfirmation) {
                awaitingNameConfirmation = false;
                listeningForNameConfirmation = false;
                confirmationNoResponseRunnable = null;
                reiniciarJanelaDefinicao();
            }
        };
        handler.postDelayed(confirmationNoResponseRunnable, CONFIRMATION_NO_RESPONSE_DELAY_MS);
    }

    private void cancelConfirmationNoResponsePrompt() {
        if (handler != null && confirmationNoResponseRunnable != null) {
            handler.removeCallbacks(confirmationNoResponseRunnable);
            confirmationNoResponseRunnable = null;
        }
    }

    private void agendarTimeoutNome() {
        if (handler == null) return;
        cancelNameListeningTimeout();
        nameListeningTimeoutRunnable = () -> {
            if (!isListeningName || pendingVoiceInputTarget == null || awaitingNameConfirmation || listeningForNameConfirmation) {
                nameListeningTimeoutRunnable = null;
                return;
            }
            ignoreNextNameError = true;
            pararEscutaVoz();
            repetirPromptNome();
        };
        handler.postDelayed(nameListeningTimeoutRunnable, NAME_LISTEN_WINDOW_MS);
    }

    private void cancelNameListeningTimeout() {
        if (handler != null && nameListeningTimeoutRunnable != null) {
            handler.removeCallbacks(nameListeningTimeoutRunnable);
            nameListeningTimeoutRunnable = null;
        }
    }

    private void agendarEncerramentoEscuta() {
        if (handler == null) return;
        cancelListeningWindowTimeout();
        listeningWindowTimeoutRunnable = () -> {
            if (!isListeningName) {
                listeningWindowTimeoutRunnable = null;
                return;
            }
            if (speechRecognizer != null) {
                speechRecognizer.stopListening();
            }
            listeningWindowTimeoutRunnable = null;
        };
        handler.postDelayed(listeningWindowTimeoutRunnable, NAME_LISTEN_WINDOW_MS);
    }

    private void cancelListeningWindowTimeout() {
        if (handler != null && listeningWindowTimeoutRunnable != null) {
            handler.removeCallbacks(listeningWindowTimeoutRunnable);
            listeningWindowTimeoutRunnable = null;
        }
    }

    private void reiniciarJanelaDefinicao() {
        runOnUiThread(() -> {
            if (currentNameDialog != null && currentNameDialog.isShowing()) {
                currentNameDialog.dismiss();
            }
            currentNameDialog = null;
            nameDialogShown = false;
            pararEscutaVoz();
            resetNameVoiceState();
            if (pendingNameIndex >= 0 && pendingNameIndex < frozenBoxes.size()) {
                solicitarDialogoNome();
            }
        });
    }

    private void repetirPromptNome() {
        if (pendingVoiceInputTarget == null) return;
        if (currentNameDialog == null || !currentNameDialog.isShowing()) return;
        namePromptSpoken = true;
        falarEmFila(getString(R.string.voice_prompt_timeout), () ->
                iniciarEscutaNomeComPermissao(pendingVoiceInputTarget, false));
    }

    private void emitirMensagemBoasVindas() {
        if (welcomeMessageSpoken) {
            return;
        }
        welcomeMessageSpoken = true;
        falarImediato(getString(R.string.welcome_message));
    }

    private void anunciarOrientacaoPosNomeacao() {
        registrarAtividadePeca(true);
        falarEmFila("Peça registrada. Se desejar, continue montando o diagrama.");
        agendarLembreteDescricaoInterativa();
    }

    private void agendarLembreteDescricaoInterativa() {
        nameReminderHandler.removeCallbacks(nameReminderRunnable);
        if (interactionState == InteractionState.DEFININDO_PECA || dialogoNomeAberto()) {
            return;
        }
        if (!lastPieceActivityWasDefinition) {
            return;
        }
        long now = System.currentTimeMillis();
        long elapsed = now - lastPieceActivityMs;
        long delay = elapsed >= NAME_REMINDER_DELAY_MS ? 0L : NAME_REMINDER_DELAY_MS - elapsed;
        nameReminderHandler.postDelayed(nameReminderRunnable, delay);
    }

    private boolean dialogoNomeAberto() {
        return (currentNameDialog != null && currentNameDialog.isShowing());
    }

    private void registrarAtividadePeca(boolean definicao) {
        lastPieceActivityMs = System.currentTimeMillis();
        lastPieceActivityWasDefinition = definicao;
        if (!definicao) {
            nameReminderHandler.removeCallbacks(nameReminderRunnable);
        }
    }

    private void preencherBytes(final Image.Plane[] planes, final byte[][] yuvBytes) {
        for (int i = 0; i < planes.length; ++i) {
            final ByteBuffer buffer = planes[i].getBuffer();
            if (yuvBytes[i] == null) yuvBytes[i] = new byte[buffer.capacity()];
            buffer.get(yuvBytes[i]);
        }
    }

    protected int obterOrientacaoTela() {
        switch (getWindowManager().getDefaultDisplay().getRotation()) {
            case Surface.ROTATION_270: return 270;
            case Surface.ROTATION_180: return 180;
            case Surface.ROTATION_90:  return 90;
            default: return 0;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (currentNameDialog != null && currentNameDialog.isShowing()) currentNameDialog.dismiss();
        if (removalDecisionDialog != null && removalDecisionDialog.isShowing()) removalDecisionDialog.dismiss();
        if (freezeHandler != null) freezeHandler.removeCallbacks(freezeWatcher);
        nameReminderHandler.removeCallbacks(nameReminderRunnable);
        if (contextDescriptionManager != null) {
            contextDescriptionManager.shutdown();
            contextDescriptionManager = null;
        }
        pararEscutaVoz();
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
        if (speechController != null) {
            speechController.shutdown();
            speechController = null;
        }
        if (handDetectorHelper != null) {
            handDetectorHelper.close();
            handDetectorHelper = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_CODE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            configurarFragmento();
        } else if (requestCode == AUDIO_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingRemovalDecisionRequest) {
                    iniciarEscutaDecisaoRemocaoComPermissao();
                } else if (pendingInteractiveDescriptionRequest) {
                    iniciarEscutaDescricaoInterativaComPermissao();
                } else if (pendingExportFormatRequest) {
                    iniciarEscutaFormatoExportacaoComPermissao();
                } else {
                    iniciarEscutaNomeComPermissao(pendingVoiceInputTarget);
                }
            } else {
                int toastMessage = R.string.voice_permission_denied_name;
                if (pendingExportFormatRequest) {
                    toastMessage = R.string.voice_permission_denied_format;
                } else if (pendingRemovalDecisionRequest || pendingInteractiveDescriptionRequest) {
                    toastMessage = R.string.voice_permission_denied_command;
                }
                Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show();
                pendingVoiceInputTarget = null;
                pendingInteractiveDescriptionRequest = false;
                pendingRemovalDecisionRequest = false;
                pendingExportFormatRequest = false;
            }
        }
    }

    @Override
    public void onError(String var1, int var2) {
        Log.e("Detector", "Erro: " + var1 + " (" + var2 + ")");
    }
    @Override
    public void onResults(ObjectDetectorHelper.ResultBundle var1) {}

    // ====== Diálogo ======
    private void removerPecaCongelada(int index) {
        if (index < 0 || index >= frozenBoxes.size()) return;
        boolean removedPendingPiece = pendingNameIndex == index;
        frozenBoxes.remove(index);
        frozenLabels.remove(index);
        frozenLastSeenMs.remove(index);
        if (index < frozenTypes.size()) {
            frozenTypes.remove(index);
        }
        registrarAtividadePeca(false);
        if (removedPendingPiece) {
            fecharDialogoNomeSePecaRemovida();
        } else if (pendingNameIndex > index) {
            pendingNameIndex--;
        }
    }

    private void solicitarDecisaoPecaRemovida(String nome, String tipo) {
        if (nome == null || nome.isEmpty()) return;
        if (removalDecisionDialog != null && removalDecisionDialog.isShowing()) {
            return;
        }
        pendingRemovalName = nome;
        pendingRemovalType = tipo;
        runOnUiThread(() -> {
            AlertDialog.Builder b = new AlertDialog.Builder(this).setCancelable(false);
            b.setTitle("Peça removida");
            b.setMessage("A peça " + formatarTipoPeca(tipo) + " \"" + nome + "\" saiu da mesa. Deseja excluir ou alterar a posição?");
            b.setPositiveButton("Excluir", (d, w) -> aplicarDecisaoRemocao(true));
            b.setNegativeButton("Alterar", (d, w) -> aplicarDecisaoRemocao(false));
            removalDecisionDialog = b.create();
            removalDecisionDialog.show();
            falarEmFila("A peça " + formatarTipoPeca(tipo) + " " + nome + " foi removida. Deseja excluir ou alterar a posição?", this::iniciarEscutaDecisaoRemocao);
        });
    }

    private void iniciarEscutaDecisaoRemocao() {
        if (speechRecognizer == null || speechRecognizerIntent == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingRemovalDecisionRequest = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION_CODE);
            return;
        }
        iniciarEscutaDecisaoRemocaoComPermissao();
    }

    private void iniciarEscutaDecisaoRemocaoComPermissao() {
        if (speechRecognizer == null || speechRecognizerIntent == null) return;
        pararEscutaVoz();
        listeningForRemovalDecision = true;
        pendingRemovalDecisionRequest = false;
        pendingVoiceInputTarget = null;
        try {
            isListeningName = true;
            speechRecognizer.startListening(speechRecognizerIntent);
            agendarEncerramentoEscuta();
        } catch (Exception e) {
            Log.e(TAG, "Erro ao iniciar decisão de remoção", e);
            listeningForRemovalDecision = false;
        }
    }

    private void processarDecisaoRemocao(List<String> matches) {
        listeningForRemovalDecision = false;
        if (matches == null || matches.isEmpty()) return;
        for (String spoken : matches) {
            if (spoken == null) continue;
            String normalized = Normalizer.normalize(spoken, Normalizer.Form.NFD)
                    .replaceAll("\\p{M}+", "")
                    .toLowerCase(Locale.ROOT)
                    .trim();
            if (normalized.contains("excluir") || normalized.contains("remover") || normalized.contains("apagar")) {
                aplicarDecisaoRemocao(true);
                return;
            }
            if (normalized.contains("alterar") || normalized.contains("mudar") || normalized.contains("reposicionar")
                    || normalized.contains("posicao") || normalized.contains("posição")) {
                aplicarDecisaoRemocao(false);
                return;
            }
        }
        falarEmFila("Não entendi. Diga excluir ou alterar a posição.", this::iniciarEscutaDecisaoRemocao);
    }

    private void aplicarDecisaoRemocao(boolean excluir) {
        pararEscutaVoz();
        pendingRemovalDecisionRequest = false;
        if (removalDecisionDialog != null && removalDecisionDialog.isShowing()) {
            removalDecisionDialog.dismiss();
        }
        removalDecisionDialog = null;
        if (excluir) {
            falarEmFila("Peça excluída.");
            pendingRemovalName = null;
            pendingRemovalType = null;
            return;
        }
        iniciarReposicionamento(pendingRemovalName, pendingRemovalType);
        pendingRemovalName = null;
        pendingRemovalType = null;
    }

    private void iniciarReposicionamento(String nome, String tipo) {
        pendingRelocationName = nome;
        pendingRelocationType = tipo;
        relocationLastBox = null;
        relocationStableSinceMs = 0L;
        falarEmFila("Reposicione a peça do mesmo tipo por pelo menos três segundos para manter o nome.");
    }

    private boolean tentarReposicionamento(List<Recognition> stableCandidates, long now) {
        if (pendingRelocationType == null || pendingRelocationName == null) {
            relocationLastBox = null;
            relocationStableSinceMs = 0L;
            return false;
        }
        Recognition candidate = melhorReconhecimentoPorTipo(stableCandidates, pendingRelocationType);
        if (candidate == null || candidate.getLocation() == null) {
            relocationLastBox = null;
            relocationStableSinceMs = 0L;
            return false;
        }
        RectF curr = candidate.getLocation();
        if (relocationLastBox == null) {
            relocationLastBox = new RectF(curr);
            relocationStableSinceMs = now;
            return true;
        }
        if (centroProximoSuficiente(relocationLastBox, curr)) {
            if (relocationStableSinceMs == 0L) {
                relocationStableSinceMs = now;
            }
            if ((now - relocationStableSinceMs) >= STABILITY_MS) {
                adicionarPecaReposicionada(curr, pendingRelocationName, pendingRelocationType);
                pendingRelocationName = null;
                pendingRelocationType = null;
                relocationLastBox = null;
                relocationStableSinceMs = 0L;
                return false;
            }
        } else {
            relocationLastBox = new RectF(curr);
            relocationStableSinceMs = now;
        }
        return true;
    }

    private Recognition melhorReconhecimentoPorTipo(List<Recognition> candidates, String tipo) {
        if (candidates == null || candidates.isEmpty() || tipo == null) return null;
        Recognition melhor = null;
        for (Recognition candidate : candidates) {
            if (candidate == null) continue;
            String cTipo = candidate.getType();
            if (cTipo == null || !cTipo.equals(tipo)) continue;
            if (melhor == null || candidate.getConfidence() > melhor.getConfidence()) {
                melhor = candidate;
            }
        }
        return melhor;
    }

    private void adicionarPecaReposicionada(RectF box, String nome, String tipo) {
        if (box == null || nome == null || nome.isEmpty()) return;
        frozenBoxes.add(new RectF(box));
        frozenLabels.add(nome);
        frozenLastSeenMs.add(System.currentTimeMillis());
        frozenTypes.add(tipo);
        registrarAtividadePeca(false);
        falarEmFila("Nome mantido para " + nome + ".");
        if (trackingOverlay != null) {
            trackingOverlay.postInvalidate();
        }
    }

    private void solicitarDialogoNome() {
        if (nameDialogShown) return;
        if (currentNameDialog != null && currentNameDialog.isShowing()) return;
        if (pendingNameIndex < 0 || pendingNameIndex >= frozenBoxes.size()) return;
        nomeDefinidoPorVoz = false;

        AlertDialog.Builder b = new AlertDialog.Builder(this).setCancelable(false);
        b.setTitle("Nome da peça");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);

        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                interromperAudiosParaAcaoDePeca();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int padding = (int) (16 * getResources().getDisplayMetrics().density);
        container.setPadding(padding, padding, padding, padding);

        LinearLayout.LayoutParams fieldLayoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        input.setLayoutParams(fieldLayoutParams);

        container.addView(input);

        b.setView(container);

        b.setPositiveButton("OK", (d, w) -> {
            String name = input.getText().toString().trim();
            if (name == null) name = "";
            frozenLabels.set(pendingNameIndex, name);

            interactionState = InteractionState.AGUARDANDO_PECA;
            if (!nomeDefinidoPorVoz && !name.isEmpty()) {
                falarEmFila("Nome digitado: " + name, this::anunciarOrientacaoPosNomeacao);
            } else {
                anunciarOrientacaoPosNomeacao();
            }
            pararEscutaVoz();
            resetNameVoiceState();

            nameDialogShown = true;
            trackingOverlay.postInvalidate();
            currentNameDialog = null;
            pendingNameIndex = -1;

            pendingClassSpoken = null;
            nomeDefinidoPorVoz = false;
        });

        b.setNegativeButton("Cancelar", (d, w) -> {
            falarEmFila("Peça descartada.");
            pararEscutaVoz();
            resetNameVoiceState();
            cancelarCongelamentoSemNomePendente();
            interactionState = InteractionState.AGUARDANDO_PECA;
        });

        currentNameDialog = b.create();
        currentNameDialog.show();

        if (pendingClassSpoken != null && !pendingClassSpoken.isEmpty()) {
            boolean vogal = pendingClassSpoken.matches("^[aeiouáéíóúâêîôûãõ].*");
            String artigo = vogal ? "uma" : "um";
            falarEmFila("A peça inserida é " + artigo + " " + pendingClassSpoken + ". Digite o que " + pendingClassSpoken + " representa e clique em OK, ou diga por comando de voz após o sinal.",
                    () -> iniciarEscutaNomeComPermissao(input, false));
        } else {
            iniciarEscutaNomeComPermissao(input, true);
        }
    }

    private void cancelarCongelamentoSemNomePendente() {
        if (pendingNameIndex >= 0 && pendingNameIndex < frozenBoxes.size()) {
            String lbl = frozenLabels.get(pendingNameIndex);
            if (lbl == null || lbl.isEmpty()) {
                frozenBoxes.remove(pendingNameIndex);
                frozenLabels.remove(pendingNameIndex);
                if (pendingNameIndex < frozenTypes.size()) {
                    frozenTypes.remove(pendingNameIndex);
                }
                if (pendingNameIndex < frozenLastSeenMs.size()) {
                    frozenLastSeenMs.remove(pendingNameIndex);
                }
            }
        }
        pendingNameIndex = -1;
        pendingClassSpoken = null;
        nameDialogShown = true;
        currentNameDialog = null;
        pararEscutaVoz();
        resetNameVoiceState();
        interactionState = InteractionState.AGUARDANDO_PECA;

        lastBox = null;
        lastStableLabel = null;
        stableSinceMs = 0L;

        if (trackingOverlay != null) trackingOverlay.postInvalidate();

        nameReminderHandler.removeCallbacks(nameReminderRunnable);
    }

    private void fecharDialogoNomeSePecaRemovida() {
        runOnUiThread(() -> {
            if (currentNameDialog != null && currentNameDialog.isShowing()) {
                currentNameDialog.dismiss();
            }
            currentNameDialog = null;
        });

        nameReminderHandler.removeCallbacks(nameReminderRunnable);
        pararEscutaVoz();
        resetNameVoiceState();

        pendingNameIndex = -1;
        pendingClassSpoken = null;
        nameDialogShown = true;
        interactionState = InteractionState.AGUARDANDO_PECA;
    }

    private void iniciarCongelamento(RectF boxToFreeze, String rotuloCru) {
        if (boxToFreeze == null) return;
        frozenBoxes.add(new RectF(boxToFreeze));
        frozenLabels.add("");
        frozenLastSeenMs.add(System.currentTimeMillis());
        frozenTypes.add(determinarTipoPeca(rotuloCru));
        pendingClassSpoken = rotuloAmigavel(rotuloCru);
        pendingNameIndex = frozenBoxes.size() - 1;
        nameDialogShown = false;
        currentNameDialog = null;
        nameReminderHandler.removeCallbacks(nameReminderRunnable);
        interactionState = InteractionState.DEFININDO_PECA;
        runOnUiThread(this::solicitarDialogoNome);
    }

    private boolean centroProximoSuficiente(RectF a, RectF b) { return centroProximoComFracao(a, b, CENTER_TOL_FRAC); }
    private boolean centroProximoComFracao(RectF a, RectF b, float frac) {
        if (a == null || b == null) return false;
        float ax = (a.left + a.right) * 0.5f, ay = (a.top + a.bottom) * 0.5f;
        float bx = (b.left + b.right) * 0.5f, by = (b.top + b.bottom) * 0.5f;
        float dx = ax - bx, dy = ay - by;
        float diag = (float) Math.hypot(Math.max(1f, a.width()), Math.max(1f, a.height()));
        float tolPx = Math.max(8f, frac * diag);
        return (dx * dx + dy * dy) <= (tolPx * tolPx);
    }

    private Recognition melhorReconhecimento(List<Recognition> reconhecimentos) {
        if (reconhecimentos == null || reconhecimentos.isEmpty()) return null;
        Recognition melhor = reconhecimentos.get(0);
        for (int i = 1; i < reconhecimentos.size(); i++) {
            if (reconhecimentos.get(i).getConfidence() > melhor.getConfidence()) melhor = reconhecimentos.get(i);
        }
        return melhor;
    }

    private String obterRotuloReconhecimento(Recognition reconhecimento) {
        if (reconhecimento == null) return null;
        try { if (reconhecimento.getTitle() != null) return reconhecimento.getTitle(); } catch (Throwable ignored) {}
        try {
            java.lang.reflect.Method metodo = reconhecimento.getClass().getMethod("getLabel");
            Object retorno = metodo.invoke(reconhecimento);
            if (retorno != null) return String.valueOf(retorno);
        } catch (Throwable ignored) {}
        try {
            java.lang.reflect.Method metodo = reconhecimento.getClass().getMethod("getDisplayName");
            Object retorno = metodo.invoke(reconhecimento);
            if (retorno != null) return String.valueOf(retorno);
        } catch (Throwable ignored) {}
        return null;
    }

    private float calcularIou(RectF a, RectF b) {
        if (a == null || b == null) return 0f;
        float interW = Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left));
        float interH = Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
        float inter = interW * interH;
        float areaA = Math.max(0, a.width()) * Math.max(0, a.height());
        float areaB = Math.max(0, b.width()) * Math.max(0, b.height());
        float uni = areaA + areaB - inter;
        return uni <= 0 ? 0 : inter / uni;
    }

    private boolean sobrepoeAlgumCongelado(RectF caixa, float limite) {
        if (caixa == null) return false;
        for (RectF congelada : frozenBoxes) {
            if (calcularIou(caixa, congelada) > limite) return true;
        }
        return false;
    }

    private boolean sobrepoeAlgumCongelado(RectF caixa, float limite, int ignorarIndex) {
        if (caixa == null) return false;
        for (int i = 0; i < frozenBoxes.size(); i++) {
            if (i == ignorarIndex) continue;
            RectF congelada = frozenBoxes.get(i);
            if (calcularIou(caixa, congelada) > limite) return true;
        }
        return false;
    }

    private void atualizarCaixaCongelada(int index, RectF nova) {
        if (index < 0 || index >= frozenBoxes.size() || nova == null) return;
        frozenBoxes.set(index, new RectF(nova));
    }

    private int encontrarMelhorReconhecimentoPorTipo(List<Recognition> recognitions, String tipo, RectF referencia, boolean[] usados) {
        return encontrarMelhorReconhecimentoPorTipo(recognitions, tipo, referencia, usados, null);
    }

    private int encontrarMelhorReconhecimentoPorTipo(List<Recognition> recognitions, String tipo, RectF referencia, boolean[] usados, RectF pendingBox) {
        if (recognitions == null || recognitions.isEmpty() || tipo == null) return -1;
        int melhorIndice = -1;
        float menorDistancia = Float.MAX_VALUE;
        float maxDistancia = Float.MAX_VALUE;
        if (previewWidth > 0 && previewHeight > 0) {
            maxDistancia = Math.max(previewWidth, previewHeight) * 0.6f;
        }
        for (int i = 0; i < recognitions.size(); i++) {
            if (usados != null && i < usados.length && usados[i]) continue;
            Recognition r = recognitions.get(i);
            if (r == null) continue;
            String rTipo = r.getType();
            if (rTipo == null || !rTipo.equals(tipo)) continue;
            RectF loc = r.getLocation();
            if (loc == null) continue;
            if (pendingBox != null && sobrepoePecaEmDefinicao(loc, pendingBox, PENDING_PIECE_EXCLUSION_IOU)) {
                continue;
            }
            float distancia = distanciaCentros(referencia, loc);
            if (distancia <= maxDistancia && distancia < menorDistancia) {
                menorDistancia = distancia;
                melhorIndice = i;
            }
        }
        return melhorIndice;
    }

    private RectF obterCaixaPecaEmDefinicao() {
        if (interactionState != InteractionState.DEFININDO_PECA) return null;
        if (pendingNameIndex < 0 || pendingNameIndex >= frozenBoxes.size()) return null;
        return frozenBoxes.get(pendingNameIndex);
    }

    private boolean sobrepoePecaEmDefinicao(RectF caixa, RectF pendingBox, float limite) {
        if (caixa == null || pendingBox == null) return false;
        return calcularIou(caixa, pendingBox) > limite;
    }

    private float distanciaCentros(RectF a, RectF b) {
        if (a == null || b == null) return Float.MAX_VALUE;
        float ax = (a.left + a.right) / 2f;
        float ay = (a.top + a.bottom) / 2f;
        float bx = (b.left + b.right) / 2f;
        float by = (b.top + b.bottom) / 2f;
        float dx = ax - bx;
        float dy = ay - by;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private String determinarTipoPeca(String rotuloBruto) {
        if (rotuloBruto == null) return null;
        String normalizado = normalizarRotulo(rotuloBruto);
        if (ehClasseNd(normalizado)) return "nd";
        if (normalizado.contains("actor") || normalizado.contains("ator")) return "ator";
        if (normalizado.contains("use case") || normalizado.contains("usecase") || normalizado.contains("caso de uso") || normalizado.contains("usercase")) {
            return "caso de uso";
        }
        if (normalizado.contains("relacionamento") || normalizado.contains("relationship") || normalizado.contains("include") || normalizado.contains("extend")) {
            return "relacionamento";
        }
        return null;
    }

    private RectF calcularRoiMesa(int width, int height) {
        if (width <= 0 || height <= 0) return null;

        float roiWidth = width * ROI_WIDTH_FRACTION;
        float roiHeight = height * ROI_HEIGHT_FRACTION;
        float left = (width - roiWidth) / 2f;
        float top = (height - roiHeight) / 2f;

        return new RectF(
                left,
                top,
                left + roiWidth,
                top + roiHeight
        );
    }

    private RectF limitarParaRoi(RectF box) {
        RectF roi = detectionRoi;
        if (box == null || roi == null) return box;
        RectF inter = new RectF(
                Math.max(box.left, roi.left),
                Math.max(box.top, roi.top),
                Math.min(box.right, roi.right),
                Math.min(box.bottom, roi.bottom)
        );
        if (inter.left >= inter.right || inter.top >= inter.bottom) {
            return null;
        }
        return inter;
    }

    private void desenharRoi(Canvas canvas) {
        RectF roi = detectionRoi;
        if (roi == null || canvas == null || previewWidth <= 0 || previewHeight <= 0) return;
        boolean rotated = sensorOrientation % 180 == 90;
        float multiplier =
                Math.min(
                        canvas.getHeight() / (float) (rotated ? previewWidth : previewHeight),
                        canvas.getWidth() / (float) (rotated ? previewHeight : previewWidth));
        Matrix frameToCanvas =
                ImageUtils.getTransformationMatrix(
                        previewWidth,
                        previewHeight,
                        (int) (multiplier * (rotated ? previewHeight : previewWidth)),
                        (int) (multiplier * (rotated ? previewWidth : previewHeight)),
                        sensorOrientation,
                        false);
        RectF roiTela = new RectF(roi);
        frameToCanvas.mapRect(roiTela);
        canvas.drawRect(roiTela, roiPaint);
        desenharLegendaDeteccao(canvas, roiTela);
    }

    private void desenharLegendaDeteccao(Canvas canvas, RectF roiTela) {
        if (canvas == null || roiTela == null) return;

        float padding = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 8f, getResources().getDisplayMetrics());
        float bulletSize = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 10f, getResources().getDisplayMetrics());
        float lineSpacing = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 6f, getResources().getDisplayMetrics());
        float textGap = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 6f, getResources().getDisplayMetrics());

        String[] labels = {"Ator", "Caso de Uso", "Relacionamento"};
        Paint[] bulletPaints = {roiActorLegendPaint, roiUseCaseLegendPaint, roiRelationLegendPaint};

        Paint.FontMetrics fontMetrics = roiLegendTextPaint.getFontMetrics();
        float lineHeight = fontMetrics.descent - fontMetrics.ascent;
        float legendHeight = padding * 2f + (lineHeight * labels.length) + (lineSpacing * (labels.length - 1));

        float maxTextWidth = 0f;
        for (String label : labels) {
            maxTextWidth = Math.max(maxTextWidth, roiLegendTextPaint.measureText(label));
        }

        float legendWidth = padding * 2f + bulletSize + textGap + maxTextWidth;
        float left = roiTela.left + padding;
        float top = roiTela.top + padding;
        float right = Math.min(left + legendWidth, roiTela.right - padding);
        float bottom = Math.min(top + legendHeight, roiTela.bottom - padding);

        if (right <= left || bottom <= top) return;

        RectF legendRect = new RectF(left, top, right, bottom);
        float cornerRadius = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 8f, getResources().getDisplayMetrics());
        canvas.drawRoundRect(legendRect, cornerRadius, cornerRadius, roiLegendBackgroundPaint);

        float currentY = legendRect.top + padding - fontMetrics.ascent;
        for (int i = 0; i < labels.length; i++) {
            float bulletTop = currentY + fontMetrics.ascent + (lineHeight - bulletSize) / 2f;
            float bulletLeft = legendRect.left + padding;
            float bulletRight = bulletLeft + bulletSize;
            float bulletBottom = bulletTop + bulletSize;
            canvas.drawRoundRect(new RectF(bulletLeft, bulletTop, bulletRight, bulletBottom),
                    bulletSize / 3f, bulletSize / 3f, bulletPaints[i]);

            float textX = bulletRight + textGap;
            canvas.drawText(labels[i], textX, currentY, roiLegendTextPaint);
            currentY += lineHeight + lineSpacing;
        }
    }

    private Bitmap aplicarRecorteRoi(Bitmap frame) {
        RectF roi = detectionRoi;
        if (frame == null || roi == null) return frame;
        if (roiMaskedBitmap == null
                || roiMaskedBitmap.getWidth() != frame.getWidth()
                || roiMaskedBitmap.getHeight() != frame.getHeight()) {
            roiMaskedBitmap = Bitmap.createBitmap(frame.getWidth(), frame.getHeight(), Bitmap.Config.ARGB_8888);
        }
        Canvas canvas = new Canvas(roiMaskedBitmap);
        canvas.drawColor(Color.GRAY);
        Rect src = new Rect(
                Math.max(0, Math.round(roi.left)),
                Math.max(0, Math.round(roi.top)),
                Math.min(frame.getWidth(), Math.round(roi.right)),
                Math.min(frame.getHeight(), Math.round(roi.bottom))
        );
        canvas.drawBitmap(frame, src, roi, null);
        return roiMaskedBitmap;
    }

    private String rotuloAmigavel(String rotuloBruto) {
        if (rotuloBruto == null) return "peça";
        String normalizado = normalizarRotulo(rotuloBruto);
        if (ehClasseNd(normalizado)) return "ND";
        if (normalizado.contains("actor") || normalizado.contains("ator")) return "ator";
        if (normalizado.contains("use case") || normalizado.contains("usercase") || normalizado.contains("caso de uso")) return "caso de uso";
        if (normalizado.contains("system") && (normalizado.contains("boundary") || normalizado.contains("fronteira"))) return "fronteira do sistema";
        if (normalizado.contains("package") || normalizado.contains("pacote")) return "pacote";
        if (normalizado.contains("include")) return "relação include";
        if (normalizado.contains("extend"))  return "relação extend";
        return normalizado;
    }

    private boolean ehClasseNd(String rotuloBruto) {
        if (rotuloBruto == null) return false;
        return rotulosNd.contains(normalizarRotulo(rotuloBruto));
    }

    private String normalizarRotulo(String rotuloBruto) {
        if (rotuloBruto == null) return "";
        return rotuloBruto.trim()
                .toLowerCase(Locale.ROOT)
                .replace('_', ' ')
                .replace('-', ' ')
                .replaceAll("\\s+", " ");
    }
}
