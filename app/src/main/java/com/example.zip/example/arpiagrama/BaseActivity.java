package com.example.arpiagrama;

import android.content.Context;
import android.view.KeyEvent;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ThemePreferences.applyFontScale(newBase));
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() != KeyEvent.ACTION_DOWN) {
            return super.dispatchKeyEvent(event);
        }

        if (event.getKeyCode() == KeyEvent.KEYCODE_TAB && handleTabNavigation(event)) {
            return true;
        }

        if ((event.getKeyCode() == KeyEvent.KEYCODE_F1 || event.getKeyCode() == KeyEvent.KEYCODE_F2)
                && onFunctionKeyPressed(event.getKeyCode())) {
            return true;
        }

        return super.dispatchKeyEvent(event);
    }

    protected boolean onFunctionKeyPressed(int keyCode) {
        if (keyCode == KeyEvent.KEYCODE_F1) {
            return clickIfVisible(R.id.button_context_description);
        }
        if (keyCode == KeyEvent.KEYCODE_F2) {
            return clickIfVisible(R.id.button_save_volunteer)
                    || clickIfVisible(R.id.button_download_image);
        }
        return false;
    }

    private boolean clickIfVisible(int viewId) {
        View view = findViewById(viewId);
        if (view != null && view.isShown() && view.isEnabled()) {
            view.performClick();
            return true;
        }
        return false;
    }

    private boolean handleTabNavigation(KeyEvent event) {
        View currentFocus = getCurrentFocus();
        if (currentFocus == null) {
            return false;
        }

        int direction = event.isShiftPressed() ? View.FOCUS_BACKWARD : View.FOCUS_FORWARD;
        View nextFocus = currentFocus.focusSearch(direction);
        if (nextFocus != null) {
            nextFocus.requestFocus();
            return true;
        }
        return false;
    }
}
