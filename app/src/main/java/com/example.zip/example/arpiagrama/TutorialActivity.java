package com.example.arpiagrama;

import android.os.Bundle;
import android.widget.Button;

public class TutorialActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);

        Button backButton = findViewById(R.id.button_tutorial_back);
        backButton.setOnClickListener(view -> finish());
    }
}
